package pzy.move.horre.packs;

import org.junit.jupiter.api.Test;
import pzy.move.horre.physics.PzyTransform;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import static org.junit.jupiter.api.Assertions.*;

class PzyAnimationClipTest {
    @Test void interpolatesBetweenKeyframes() {
        PzyAnimationClip clip = new PzyAnimationClip();
        clip.id = "test";
        clip.lengthTicks = 10.0f;
        clip.bones.put("arm", new ArrayList<>());
        PzyAnimationKeyframe start = new PzyAnimationKeyframe();
        start.tick = 0;
        start.x = 0;
        PzyAnimationKeyframe end = new PzyAnimationKeyframe();
        end.tick = 10;
        end.x = 1;
        clip.bones.get("arm").add(end);
        clip.bones.get("arm").add(start);
        clip.normalize();

        PzyTransform middle = clip.sample("arm", 5);
        assertEquals(0.5f, middle.x, 0.0001f);
    }

    @Test void rotationInterpolationUsesShortestAnglePath() {
        PzyAnimationClip clip = new PzyAnimationClip();
        clip.lengthTicks = 10.0f;
        clip.bones.put("arm", new ArrayList<>());
        PzyAnimationKeyframe start = new PzyAnimationKeyframe();
        start.tick = 0;
        start.rotateZ = 179.0f;
        PzyAnimationKeyframe end = new PzyAnimationKeyframe();
        end.tick = 10;
        end.rotateZ = -179.0f;
        clip.bones.get("arm").add(start);
        clip.bones.get("arm").add(end);
        clip.normalize();
        assertEquals(180.0f, Math.abs(clip.sample("arm", 5).rotateZ), 0.01f);
    }


    @Test void normalizationCapsAggregateFrameCount() {
        PzyAnimationClip clip = new PzyAnimationClip();
        for (int boneIndex = 0; boneIndex < 12; boneIndex++) {
            var frames = new ArrayList<PzyAnimationKeyframe>();
            for (int frameIndex = 0; frameIndex < 512; frameIndex++) {
                PzyAnimationKeyframe frame = new PzyAnimationKeyframe();
                frame.tick = frameIndex;
                frames.add(frame);
            }
            clip.bones.put("bone_" + boneIndex, frames);
        }
        clip.normalize();
        int total = clip.bones.values().stream().mapToInt(java.util.List::size).sum();
        assertTrue(total <= 4096);
    }

    @Test void loopUsesPositiveTimeModulo() {
        PzyAnimationClip clip = new PzyAnimationClip();
        clip.lengthTicks = 10.0f;
        clip.loop = true;
        clip.bones = new LinkedHashMap<>();
        clip.bones.put("root", new ArrayList<>());
        PzyAnimationKeyframe frame = new PzyAnimationKeyframe();
        frame.tick = 0;
        frame.y = 0.25f;
        clip.bones.get("root").add(frame);
        clip.normalize();

        assertEquals(0.25f, clip.sample("root", -1).y, 0.0001f);
    }
}
