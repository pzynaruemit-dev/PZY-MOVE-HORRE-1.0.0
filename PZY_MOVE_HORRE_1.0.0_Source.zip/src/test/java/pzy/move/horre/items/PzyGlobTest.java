package pzy.move.horre.items;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PzyGlobTest {
    @Test void matchesExactItemId() { assertTrue(PzyGlob.matches("minecraft:diamond_sword", "minecraft:diamond_sword")); }
    @Test void matchesModNamespaceShortcut() { assertTrue(PzyGlob.matches("examplemod", "examplemod:cool_item")); }
    @Test void matchesWildcards() { assertTrue(PzyGlob.matches("minecraft:*_sword", "minecraft:netherite_sword")); }
    @Test void bareWildcardMatchesAnyNamespacePath() { assertTrue(PzyGlob.matches("*_sword", "examplemod:obsidian_sword")); }
    @Test void barePathSubstringMatchesAnyNamespace() { assertTrue(PzyGlob.matches("axe_?", "examplemod:axe_a")); }
    @Test void questionMarkMatchesOneCharacter() { assertTrue(PzyGlob.matches("minecraft:axe_?", "minecraft:axe_a")); }
    @Test void rejectsDifferentNamespace() { assertFalse(PzyGlob.matches("minecraft:*_sword", "examplemod:diamond_sword")); }
}
