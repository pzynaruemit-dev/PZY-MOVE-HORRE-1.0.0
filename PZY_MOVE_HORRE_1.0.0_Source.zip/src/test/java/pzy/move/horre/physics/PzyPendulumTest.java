package pzy.move.horre.physics;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PzyPendulumTest {
    @Test void settlesTowardTarget() {
        PzyPendulum pendulum = new PzyPendulum();
        for (int i = 0; i < 120; i++) pendulum.step(1.0f, 0.16f, 0.82f);
        assertTrue(Math.abs(pendulum.value() - 1.0f) < 0.02f);
    }

    @Test void resetClearsState() {
        PzyPendulum pendulum = new PzyPendulum();
        for (int i = 0; i < 10; i++) pendulum.step(1.0f, 0.16f, 0.82f);
        pendulum.reset();
        assertEquals(0.0f, pendulum.value());
    }
}
