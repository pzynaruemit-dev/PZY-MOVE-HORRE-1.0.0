package pzy.move.horre.items;

import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

/** Classifies an item by its stable registry id, with class-based fallbacks. */
public final class PzyItemClassifier {
    private PzyItemClassifier() { }

    public static PzyItemCategory classify(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return PzyItemCategory.EMPTY_HAND;
        Identifier id = Registries.ITEM.getId(stack.getItem());
        String path = id.getPath();
        if (path.contains("sword")) return PzyItemCategory.SWORD;
        if (path.contains("pickaxe")) return PzyItemCategory.PICKAXE;
        if (path.contains("axe")) return PzyItemCategory.AXE;
        if (path.contains("shovel")) return PzyItemCategory.SHOVEL;
        if (path.contains("hoe")) return PzyItemCategory.HOE;
        if (path.contains("shears")) return PzyItemCategory.SHEARS;
        if (path.contains("shield")) return PzyItemCategory.SHIELD;
        if (path.contains("crossbow")) return PzyItemCategory.CROSSBOW;
        if (path.contains("bow")) return PzyItemCategory.BOW;
        if (path.contains("trident")) return PzyItemCategory.TRIDENT;
        if (path.contains("mace")) return PzyItemCategory.MACE;
        if (path.contains("spyglass")) return PzyItemCategory.SPYGLASS;
        if (path.contains("fishing_rod")) return PzyItemCategory.FISHING_ROD;
        if (path.contains("brush")) return PzyItemCategory.BRUSH;
        if (path.contains("horn")) return PzyItemCategory.HORN;
        if (path.contains("bucket")) return PzyItemCategory.BUCKET;
        if (path.contains("potion") || path.contains("honey_bottle")) return PzyItemCategory.POTION;
        if (path.contains("torch")) return PzyItemCategory.TORCH;
        if (path.contains("lantern")) return PzyItemCategory.LANTERN;
        if (path.contains("boat") || path.contains("raft")) return PzyItemCategory.BOAT;
        if (path.contains("minecart")) return PzyItemCategory.MINECART;
        if (path.contains("flint_and_steel")) return PzyItemCategory.FLINT_AND_STEEL;
        if (path.contains("redstone") || path.contains("repeater") || path.contains("comparator") || path.contains("lever")) return PzyItemCategory.REDSTONE;
        if (stack.getItem() instanceof BlockItem) return PzyItemCategory.BLOCK;
        if (path.contains("hammer") || path.contains("wrench") || path.contains("drill")) return PzyItemCategory.TOOL;
        if (looksLikeFood(path)) return PzyItemCategory.FOOD;
        return PzyItemCategory.OTHER;
    }

    private static boolean looksLikeFood(String path) {
        return path.contains("apple") || path.contains("bread") || path.contains("beef") ||
            path.contains("pork") || path.contains("chicken") || path.contains("mutton") ||
            path.contains("rabbit") || path.contains("stew") || path.contains("cookie") ||
            path.contains("carrot") || path.contains("potato") || path.contains("melon") ||
            path.contains("berry") || path.contains("fish") || path.contains("salmon") ||
            path.contains("cod") || path.contains("pie") || path.contains("chorus_fruit") ||
            path.contains("golden_carrot") || path.contains("rotten_flesh");
    }

    public static String id(ItemStack stack) {
        return stack == null || stack.isEmpty() ? "minecraft:air" : Registries.ITEM.getId(stack.getItem()).toString();
    }
}
