package pzy.move.horre.items;

/** PZY first-person item taxonomy used by pack selection and per-category tuning. */
public enum PzyItemCategory {
    EMPTY_HAND,
    SWORD, AXE, PICKAXE, SHOVEL, HOE, SHEARS, TOOL,
    SHIELD, BLOCK,
    BOW, CROSSBOW, TRIDENT, MACE,
    FOOD, POTION, BUCKET,
    SPYGLASS, FISHING_ROD, BRUSH, HORN, FLINT_AND_STEEL,
    TORCH, LANTERN, BOAT, MINECART, REDSTONE,
    OTHER
}
