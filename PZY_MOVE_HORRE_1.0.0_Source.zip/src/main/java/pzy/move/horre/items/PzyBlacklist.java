package pzy.move.horre.items;

import net.minecraft.item.ItemStack;
import pzy.move.horre.PzyMoveHorreClient;

public final class PzyBlacklist {
    private PzyBlacklist() { }

    public static boolean isBlocked(ItemStack stack, boolean offHand) {
        if (stack == null || stack.isEmpty()) return PzyMoveHorreClient.CONFIG.vanillaEmptyHand;
        String id = PzyItemClassifier.id(stack);
        for (PzyBlacklistEntry entry : PzyMoveHorreClient.CONFIG.blacklist) {
            if (entry == null || entry.pattern == null) continue;
            String hand = entry.hand == null ? "BOTH" : entry.hand;
            if ("MAIN".equalsIgnoreCase(hand) && offHand) continue;
            if ("OFF".equalsIgnoreCase(hand) && !offHand) continue;
            if (PzyGlob.matches(entry.pattern, id)) return true;
        }
        return false;
    }
}
