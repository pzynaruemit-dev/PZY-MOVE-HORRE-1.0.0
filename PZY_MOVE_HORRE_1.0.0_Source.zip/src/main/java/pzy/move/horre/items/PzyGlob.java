package pzy.move.horre.items;

import java.util.Locale;
import java.util.regex.Pattern;

/** Glob matcher for registry ids. Bare mod ids match a namespace; bare globs match any namespace path. */
public final class PzyGlob {
    private PzyGlob() { }

    public static boolean matches(String pattern, String value) {
        if (pattern == null || pattern.isBlank() || value == null || value.isBlank()) return false;
        String normalized = pattern.trim().toLowerCase(Locale.ROOT);
        if (!normalized.contains(":")) {
            if (normalized.indexOf('*') < 0 && normalized.indexOf('?') < 0) normalized += ":*";
            else normalized = "*:" + normalized;
        }
        StringBuilder regex = new StringBuilder("^");
        for (int i = 0; i < normalized.length(); i++) {
            char c = normalized.charAt(i);
            if (c == '*') regex.append(".*");
            else if (c == '?') regex.append('.');
            else regex.append(Pattern.quote(String.valueOf(c)));
        }
        regex.append('$');
        return Pattern.compile(regex.toString()).matcher(value.toLowerCase(Locale.ROOT)).matches();
    }
}
