package pzy.move.horre.items;

public final class PzyBlacklistEntry {
    public String pattern;
    /** BOTH, MAIN or OFF. */
    public String hand = "BOTH";

    public PzyBlacklistEntry() { }

    public PzyBlacklistEntry(String pattern) {
        this.pattern = pattern;
    }
}
