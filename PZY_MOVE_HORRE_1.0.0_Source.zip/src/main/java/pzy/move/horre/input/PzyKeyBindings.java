package pzy.move.horre.input;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class PzyKeyBindings {
    public static KeyBinding OPEN_MENU;
    public static KeyBinding INSPECT;
    public static KeyBinding RELOAD_PACKS;

    private PzyKeyBindings() { }

    public static void register() {
        OPEN_MENU = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.pzy_move_horre.open_menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F8,
            "category.pzy_move_horre.main"));
        INSPECT = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.pzy_move_horre.inspect", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_I,
            "category.pzy_move_horre.main"));
        RELOAD_PACKS = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.pzy_move_horre.reload_packs", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K,
            "category.pzy_move_horre.main"));
    }
}
