package pzy.move.horre.physics;

public final class PzyTransform {
    public float x, y, z;
    public float rotateX, rotateY, rotateZ;
    public float scale = 1.0f;

    public PzyTransform add(PzyTransform other) {
        x += other.x; y += other.y; z += other.z;
        rotateX += other.rotateX; rotateY += other.rotateY; rotateZ += other.rotateZ;
        scale *= other.scale;
        return this;
    }
}
