package pzy.move.horre.physics;

import net.minecraft.util.Hand;
import net.minecraft.util.Arm;
import net.minecraft.client.MinecraftClient;
import pzy.move.horre.PzyMoveHorreClient;
import pzy.move.horre.motion.PzyMotionSnapshot;
import pzy.move.horre.motion.PzyMotionTracker;

import java.util.EnumMap;
import java.util.Map;

/** Separate damped motion channels for the two hands and their held items. */
public final class PzyPhysicsSystem {
    private static final Map<Hand, PzyPendulum> ARM_ROLL = new EnumMap<>(Hand.class);
    private static final Map<Hand, PzyPendulum> ARM_PITCH = new EnumMap<>(Hand.class);
    private static final Map<Hand, PzyPendulum> ITEM_ROLL = new EnumMap<>(Hand.class);
    private static final Map<Hand, PzyPendulum> ITEM_PITCH = new EnumMap<>(Hand.class);

    static {
        for (Hand hand : Hand.values()) {
            ARM_ROLL.put(hand, new PzyPendulum());
            ARM_PITCH.put(hand, new PzyPendulum());
            ITEM_ROLL.put(hand, new PzyPendulum());
            ITEM_PITCH.put(hand, new PzyPendulum());
        }
    }

    private PzyPhysicsSystem() { }

    public static void tick() {
        PzyMotionSnapshot motion = PzyMotionTracker.get();
        float sprintScale = motion.sprinting ? 1.25f : 1.0f;
        boolean mainHandOnRight = MinecraftClient.getInstance().player == null ||
            MinecraftClient.getInstance().player.getMainArm() == Arm.RIGHT;
        for (Hand hand : Hand.values()) {
            float handedness = hand == Hand.MAIN_HAND ? (mainHandOnRight ? 1.0f : -1.0f) : (mainHandOnRight ? -1.0f : 1.0f);
            ARM_ROLL.get(hand).step(-motion.yawDelta * 0.06f * handedness, 0.16f, PzyMoveHorreClient.CONFIG.physicsDamping);
            ARM_PITCH.get(hand).step(motion.pitchDelta * 0.045f, 0.14f, PzyMoveHorreClient.CONFIG.physicsDamping);
            ITEM_ROLL.get(hand).step(-motion.yawDelta * 0.11f * handedness * sprintScale - motion.accelerationX * 20.0f, 0.12f, PzyMoveHorreClient.CONFIG.physicsDamping);
            ITEM_PITCH.get(hand).step(motion.pitchDelta * 0.075f - motion.accelerationZ * 16.0f, 0.12f, PzyMoveHorreClient.CONFIG.physicsDamping);
        }
    }

    public static PzyTransform getHandTransform(Hand hand) {
        PzyTransform transform = new PzyTransform();
        if (!PzyMoveHorreClient.CONFIG.enableArmPhysics) return transform;
        float strength = PzyMoveHorreClient.CONFIG.armPhysicsStrength;
        transform.rotateZ = ARM_ROLL.get(hand).value() * strength;
        transform.rotateX = ARM_PITCH.get(hand).value() * strength;
        return transform;
    }

    public static PzyTransform getItemTransform(Hand hand) {
        PzyTransform transform = new PzyTransform();
        if (!PzyMoveHorreClient.CONFIG.enableItemPhysics) return transform;
        float strength = PzyMoveHorreClient.CONFIG.itemPhysicsStrength;
        transform.rotateZ = ITEM_ROLL.get(hand).value() * strength;
        transform.rotateX = ITEM_PITCH.get(hand).value() * strength;
        transform.y = -Math.abs(ITEM_ROLL.get(hand).value()) * 0.0005f * strength;
        return transform;
    }

    public static void reset() {
        for (Hand hand : Hand.values()) {
            ARM_ROLL.get(hand).reset(); ARM_PITCH.get(hand).reset();
            ITEM_ROLL.get(hand).reset(); ITEM_PITCH.get(hand).reset();
        }
    }
}
