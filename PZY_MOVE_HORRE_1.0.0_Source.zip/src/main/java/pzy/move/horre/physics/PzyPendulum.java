package pzy.move.horre.physics;

/** Damped spring used for hand/item follow-through. Pure math, no Minecraft dependency. */
public final class PzyPendulum {
    private float angle;
    private float velocity;

    public float step(float target, float stiffness, float damping) {
        float acceleration = (target - angle) * stiffness - velocity * damping;
        velocity += acceleration;
        angle += velocity;
        if (Math.abs(angle) < 0.0001f && Math.abs(velocity) < 0.0001f) {
            angle = 0;
            velocity = 0;
        }
        return angle;
    }

    public float value() { return angle; }

    public void reset() {
        angle = 0;
        velocity = 0;
    }
}
