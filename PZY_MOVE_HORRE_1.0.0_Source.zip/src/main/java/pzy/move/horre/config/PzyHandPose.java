package pzy.move.horre.config;

/** User-authored transform for one hand. Angles are stored in degrees. */
public final class PzyHandPose {
    public float x;
    public float y;
    public float z;
    public float rotateX;
    public float rotateY;
    public float rotateZ;
    public float scale = 1.0f;

    public PzyHandPose copy() {
        PzyHandPose result = new PzyHandPose();
        result.x = x;
        result.y = y;
        result.z = z;
        result.rotateX = rotateX;
        result.rotateY = rotateY;
        result.rotateZ = rotateZ;
        result.scale = scale;
        return result;
    }
}
