package pzy.move.horre.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import pzy.move.horre.PzyMoveHorreClient;
import pzy.move.horre.items.PzyBlacklistEntry;
import pzy.move.horre.items.PzyItemCategory;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Persisted PZY settings. Only implemented controls are exposed here. */
public final class PzyConfig {
    public static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    public static final Path CONFIG_DIR = FabricLoader.getInstance().getConfigDir().resolve("pzy_move_horre");
    public static final Path CONFIG_FILE = CONFIG_DIR.resolve("pzy_config.json");

    public boolean enabled = true;
    public float animationSpeed = 1.0f;
    public boolean showBothHands = true;
    /** Keep vanilla rendering for empty hands instead of applying PZY arm motion. */
    public boolean vanillaEmptyHand = false;
    public boolean reduceMotion = false;
    public boolean enableIdleSway = true;
    public boolean enableCrouchAnimation = true;

    public boolean enableCustomWalk = true;
    public boolean enableSprintArmSwing = true;
    public float sprintArmSwingIntensity = 1.0f;
    public float sprintArmSwingSpeed = 1.0f;
    public boolean enableFallArmAnimation = true;
    public boolean enableCrawlAnimation = true;
    public boolean enableClimbAnimation = true;
    public boolean enableSwimAnimation = true;
    public boolean enableElytraFlightAnimation = true;
    public boolean enableBoatFirstPersonAnimations = true;
    public boolean enableEnhancedFireEffects = true;
    public boolean enableFreezeShake = true;

    public boolean enableArmPhysics = true;
    public boolean enableItemPhysics = true;
    public float armPhysicsStrength = 1.0f;
    public float itemPhysicsStrength = 1.0f;
    public float physicsDamping = 0.82f;

    /** Prevents double first-person arm rendering with the external First Person Model mod. */
    public boolean firstPersonModelAutoHide = true;
    public String activeProfile = "";
    public List<PzyBlacklistEntry> blacklist = new ArrayList<>();
    public Map<String, String> packChoices = new LinkedHashMap<>();
    public Map<String, Boolean> packEnabled = new LinkedHashMap<>();
    public Map<String, PzyHandPose> handPoses = new LinkedHashMap<>();
    public Map<String, Float> categoryAnimationSpeeds = new LinkedHashMap<>();

    public static PzyConfig defaults() {
        PzyConfig config = new PzyConfig();
        config.packChoices.put("DEFAULT", "pzy:default");
        for (PzyItemCategory category : PzyItemCategory.values()) {
            config.packChoices.put(category.name(), "pzy:default");
            config.categoryAnimationSpeeds.put(category.name(), 1.0f);
        }
        config.packEnabled.put("pzy:default", true);
        config.handPoses.put("main", new PzyHandPose());
        config.handPoses.put("off", new PzyHandPose());
        return config;
    }

    public static PzyConfig load() {
        try {
            Files.createDirectories(CONFIG_DIR);
            if (!Files.isRegularFile(CONFIG_FILE)) {
                PzyConfig created = defaults();
                created.save();
                return created;
            }
            try (Reader reader = Files.newBufferedReader(CONFIG_FILE)) {
                PzyConfig loaded = fromJsonTree(JsonParser.parseReader(reader));
                loaded.save(); // Persist merged defaults and sanitized values.
                return loaded;
            }
        } catch (IOException | JsonParseException exception) {
            PzyMoveHorreClient.LOGGER.error("Could not load PZY configuration; using defaults", exception);
            try {
                if (Files.exists(CONFIG_FILE)) {
                    Files.copy(CONFIG_FILE, CONFIG_DIR.resolve("pzy_config.broken.json"), StandardCopyOption.REPLACE_EXISTING);
                }
            } catch (IOException backupException) {
                PzyMoveHorreClient.LOGGER.warn("Could not preserve broken PZY config", backupException);
            }
            PzyConfig defaults = defaults();
            defaults.save();
            return defaults;
        }
    }

    public static PzyConfig fromJson(String json) {
        return fromJsonTree(JsonParser.parseString(json));
    }

    private static PzyConfig fromJsonTree(JsonElement tree) {
        if (tree == null || !tree.isJsonObject()) return defaults();
        PzyConfig loaded = GSON.fromJson(tree, PzyConfig.class);
        if (loaded == null) loaded = defaults();
        loaded.mergeMissingDefaults(tree.getAsJsonObject());
        loaded.sanitize();
        return loaded;
    }

    private void mergeMissingDefaults(JsonObject stored) {
        PzyConfig defaults = defaults();
        for (Field field : PzyConfig.class.getFields()) {
            if (Modifier.isStatic(field.getModifiers()) || stored.has(field.getName())) continue;
            try {
                field.set(this, field.get(defaults));
            } catch (IllegalAccessException exception) {
                PzyMoveHorreClient.LOGGER.warn("Could not restore default PZY config field {}", field.getName(), exception);
            }
        }
    }

    /** Clamp numbers and repair user-editable collections before they reach render code. */
    public void sanitize() {
        animationSpeed = clamp(animationSpeed, 0.1f, 4.0f, 1.0f);
        sprintArmSwingIntensity = clamp(sprintArmSwingIntensity, 0.0f, 3.0f, 1.0f);
        sprintArmSwingSpeed = clamp(sprintArmSwingSpeed, 0.1f, 4.0f, 1.0f);
        armPhysicsStrength = clamp(armPhysicsStrength, 0.0f, 3.0f, 1.0f);
        itemPhysicsStrength = clamp(itemPhysicsStrength, 0.0f, 3.0f, 1.0f);
        physicsDamping = clamp(physicsDamping, 0.0f, 0.99f, 0.82f);
        activeProfile = activeProfile == null ? "" : activeProfile.trim();
        if (activeProfile.length() > 32) activeProfile = activeProfile.substring(0, 32);

        if (blacklist == null) blacklist = new ArrayList<>();
        blacklist.removeIf(entry -> entry == null || entry.pattern == null || entry.pattern.isBlank());
        if (blacklist.size() > 256) blacklist = new ArrayList<>(blacklist.subList(0, 256));
        for (PzyBlacklistEntry entry : blacklist) {
            entry.pattern = entry.pattern.trim();
            if (entry.pattern.length() > 128) entry.pattern = entry.pattern.substring(0, 128);
            if (entry.hand == null || !(entry.hand.equalsIgnoreCase("BOTH") || entry.hand.equalsIgnoreCase("MAIN") || entry.hand.equalsIgnoreCase("OFF"))) {
                entry.hand = "BOTH";
            } else {
                entry.hand = entry.hand.toUpperCase(java.util.Locale.ROOT);
            }
        }

        if (packChoices == null) packChoices = new LinkedHashMap<>();
        if (packEnabled == null) packEnabled = new LinkedHashMap<>();
        if (handPoses == null) handPoses = new LinkedHashMap<>();
        if (categoryAnimationSpeeds == null) categoryAnimationSpeeds = new LinkedHashMap<>();
        packChoices.replaceAll((key, value) -> value == null || value.isBlank() ? "pzy:default" : value.trim());
        packChoices.putIfAbsent("DEFAULT", "pzy:default");
        for (PzyItemCategory category : PzyItemCategory.values()) {
            packChoices.putIfAbsent(category.name(), packChoices.get("DEFAULT"));
            Float storedSpeed = categoryAnimationSpeeds.get(category.name());
            categoryAnimationSpeeds.put(category.name(), clamp(storedSpeed == null ? 1.0f : storedSpeed, 0.1f, 4.0f, 1.0f));
        }
        packEnabled.put("pzy:default", true);
        packEnabled.entrySet().removeIf(entry -> entry.getKey() == null || entry.getKey().isBlank() || entry.getValue() == null);

        repairPose("main");
        repairPose("off");
        handPoses.entrySet().removeIf(entry -> entry.getKey() == null || !(entry.getKey().equals("main") || entry.getKey().equals("off")));
    }

    private void repairPose(String key) {
        PzyHandPose pose = handPoses.get(key);
        if (pose == null) pose = new PzyHandPose();
        pose.x = clamp(pose.x, -1.0f, 1.0f, 0.0f);
        pose.y = clamp(pose.y, -1.0f, 1.0f, 0.0f);
        pose.z = clamp(pose.z, -1.0f, 1.0f, 0.0f);
        pose.rotateX = clamp(pose.rotateX, -180.0f, 180.0f, 0.0f);
        pose.rotateY = clamp(pose.rotateY, -180.0f, 180.0f, 0.0f);
        pose.rotateZ = clamp(pose.rotateZ, -180.0f, 180.0f, 0.0f);
        pose.scale = clamp(pose.scale, 0.25f, 2.0f, 1.0f);
        handPoses.put(key, pose);
    }

    private static float clamp(float value, float min, float max, float fallback) {
        if (!Float.isFinite(value)) return fallback;
        return Math.max(min, Math.min(max, value));
    }

    public void save() {
        sanitize();
        try {
            Files.createDirectories(CONFIG_DIR);
            Path temporary = CONFIG_DIR.resolve("pzy_config.json.tmp");
            try (Writer writer = Files.newBufferedWriter(temporary)) {
                GSON.toJson(this, writer);
            }
            try {
                Files.move(temporary, CONFIG_FILE, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException exception) {
                Files.move(temporary, CONFIG_FILE, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException exception) {
            PzyMoveHorreClient.LOGGER.error("Could not save PZY configuration", exception);
        }
    }

    public PzyConfig copy() {
        return fromJson(GSON.toJson(this));
    }

    public void resetSettings() {
        PzyConfig defaults = GSON.fromJson(GSON.toJson(defaults()), PzyConfig.class);
        String profile = activeProfile;
        for (Field field : PzyConfig.class.getFields()) {
            if (Modifier.isStatic(field.getModifiers()) || field.getName().equals("activeProfile")) continue;
            try {
                field.set(this, field.get(defaults));
            } catch (IllegalAccessException exception) {
                PzyMoveHorreClient.LOGGER.warn("Could not reset PZY config field {}", field.getName(), exception);
            }
        }
        activeProfile = profile;
        save();
    }
}
