package pzy.move.horre.render;

import net.minecraft.util.Hand;
import pzy.move.horre.PzyMoveHorreClient;
import pzy.move.horre.config.PzyHandPose;

/** Persistent per-hand placement editor used by the config screen. */
public final class PzyHandEditor {
    private PzyHandEditor() { }

    public static PzyHandPose getPose(Hand hand) {
        String key = hand == Hand.MAIN_HAND ? "main" : "off";
        return PzyMoveHorreClient.CONFIG.handPoses.computeIfAbsent(key, ignored -> new PzyHandPose());
    }

    public static void adjust(Hand hand, Axis axis, float amount) {
        PzyHandPose pose = getPose(hand);
        switch (axis) {
            case X -> pose.x = clamp(pose.x + amount, -1.0f, 1.0f);
            case Y -> pose.y = clamp(pose.y + amount, -1.0f, 1.0f);
            case Z -> pose.z = clamp(pose.z + amount, -1.0f, 1.0f);
            case ROTATE_X -> pose.rotateX = clamp(pose.rotateX + amount, -180.0f, 180.0f);
            case ROTATE_Y -> pose.rotateY = clamp(pose.rotateY + amount, -180.0f, 180.0f);
            case ROTATE_Z -> pose.rotateZ = clamp(pose.rotateZ + amount, -180.0f, 180.0f);
            case SCALE -> pose.scale = clamp(pose.scale + amount, 0.25f, 2.0f);
        }
        PzyMoveHorreClient.CONFIG.save();
    }

    public static void reset(Hand hand) {
        String key = hand == Hand.MAIN_HAND ? "main" : "off";
        PzyMoveHorreClient.CONFIG.handPoses.put(key, new PzyHandPose());
        PzyMoveHorreClient.CONFIG.save();
    }

    private static float clamp(float value, float min, float max) { return Math.max(min, Math.min(max, value)); }
    public enum Axis { X, Y, Z, ROTATE_X, ROTATE_Y, ROTATE_Z, SCALE }
}
