package pzy.move.horre.render;

import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;

import java.util.ArrayDeque;
import java.util.Deque;

/** Scoped first-person render context shared by HeldItemRenderer and ItemRenderer mixins. */
public final class PzyRenderContext {
    private static final ThreadLocal<Deque<Entry>> STACK = ThreadLocal.withInitial(ArrayDeque::new);

    private PzyRenderContext() { }

    public static void begin(Hand hand, ItemStack stack, float tickDelta) {
        STACK.get().push(new Entry(hand, stack, tickDelta));
    }

    public static Entry current() {
        Deque<Entry> entries = STACK.get();
        return entries.isEmpty() ? null : entries.peek();
    }

    public static void end() {
        Deque<Entry> entries = STACK.get();
        if (!entries.isEmpty()) entries.pop();
        if (entries.isEmpty()) STACK.remove();
    }

    public record Entry(Hand hand, ItemStack stack, float tickDelta) {
        public boolean matches(ItemStack candidate) {
            // HeldItemRenderer passes the live hand stack to ItemRenderer; identity avoids
            // confusing an identical item rendered for an unrelated GUI/entity in the same frame.
            return stack == candidate;
        }
    }
}
