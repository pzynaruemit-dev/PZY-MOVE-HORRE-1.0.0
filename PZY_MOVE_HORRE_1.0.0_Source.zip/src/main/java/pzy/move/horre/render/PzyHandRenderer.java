package pzy.move.horre.render;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Hand;
import net.minecraft.util.Arm;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.item.ItemStack;
import pzy.move.horre.PzyMoveHorreClient;
import pzy.move.horre.animation.PzyAnimationEngine;
import pzy.move.horre.compat.PzyCompatManager;
import pzy.move.horre.config.PzyHandPose;
import pzy.move.horre.items.PzyBlacklist;
import pzy.move.horre.items.PzyItemCategory;
import pzy.move.horre.items.PzyItemClassifier;
import pzy.move.horre.motion.PzyMotionSnapshot;
import pzy.move.horre.motion.PzyMotionTracker;
import pzy.move.horre.physics.PzyPhysicsSystem;
import pzy.move.horre.physics.PzyTransform;

import java.util.EnumMap;
import java.util.Map;

/** Applies PZY's own first-person transforms while preserving the vanilla skin and item renderer. */
public final class PzyHandRenderer {
    private static final Map<Hand, Float> LAST_SWING = new EnumMap<>(Hand.class);
    static { for (Hand hand : Hand.values()) LAST_SWING.put(hand, 0.0f); }

    private PzyHandRenderer() { }

    public static void apply(AbstractClientPlayerEntity player, float tickDelta, Hand hand,
                             float swingProgress, ItemStack item, MatrixStack matrices) {
        if (!PzyMoveHorreClient.CONFIG.enabled || player == null) return;
        boolean offHand = hand == Hand.OFF_HAND;
        if (PzyBlacklist.isBlocked(item, offHand)) return;
        if (PzyCompatManager.shouldDeferToExternalFirstPersonModel()) return;

        PzyItemCategory category = PzyItemClassifier.classify(item);
        String itemId = PzyItemClassifier.id(item);
        triggerAttackOnSwing(hand, category, itemId, swingProgress);

        PzyTransform transform = new PzyTransform();
        PzyHandPose userPose = PzyHandEditor.getPose(hand);
        transform.x += userPose.x;
        transform.y += userPose.y;
        transform.z += userPose.z;
        transform.rotateX += userPose.rotateX;
        transform.rotateY += userPose.rotateY;
        transform.rotateZ += userPose.rotateZ;
        transform.scale *= userPose.scale;

        float motionScale = PzyMoveHorreClient.CONFIG.reduceMotion ? 0.35f : 1.0f;
        PzyTransform handPhysics = PzyPhysicsSystem.getHandTransform(hand);
        handPhysics.x *= motionScale; handPhysics.y *= motionScale; handPhysics.z *= motionScale;
        handPhysics.rotateX *= motionScale; handPhysics.rotateY *= motionScale; handPhysics.rotateZ *= motionScale;
        transform.add(handPhysics);
        addMovementTransform(transform, player, hand, motionScale);

        transform.add(withMotionScale(PzyAnimationEngine.sample(hand, "root", tickDelta), motionScale));
        transform.add(withMotionScale(PzyAnimationEngine.sample(hand, "arm", tickDelta), motionScale));

        matrices.translate(transform.x, transform.y, transform.z);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(transform.rotateX));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(transform.rotateY));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(transform.rotateZ));
        if (Math.abs(transform.scale - 1.0f) > 0.0001f) {
            matrices.scale(transform.scale, transform.scale, transform.scale);
        }
    }

    /** Item-only transform is injected around ItemRenderer.renderItem, after the arm pose. */
    public static void applyItem(Hand hand, float tickDelta, ItemStack item, MatrixStack matrices) {
        if (!PzyMoveHorreClient.CONFIG.enabled || item == null || item.isEmpty() || PzyCompatManager.shouldDeferToExternalFirstPersonModel()) return;
        boolean offHand = hand == Hand.OFF_HAND;
        if (PzyBlacklist.isBlocked(item, offHand)) return;
        PzyTransform transform = PzyPhysicsSystem.getItemTransform(hand);
        float motionScale = PzyMoveHorreClient.CONFIG.reduceMotion ? 0.35f : 1.0f;
        transform.x *= motionScale; transform.y *= motionScale; transform.z *= motionScale;
        transform.rotateX *= motionScale; transform.rotateY *= motionScale; transform.rotateZ *= motionScale;
        transform.add(withMotionScale(PzyAnimationEngine.sample(hand, "item", tickDelta), motionScale));
        matrices.translate(transform.x, transform.y, transform.z);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(transform.rotateX));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(transform.rotateY));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(transform.rotateZ));
        if (Math.abs(transform.scale - 1.0f) > 0.0001f) matrices.scale(transform.scale, transform.scale, transform.scale);
    }

    private static PzyTransform withMotionScale(PzyTransform source, float amount) {
        PzyTransform result = new PzyTransform();
        result.x = source.x * amount;
        result.y = source.y * amount;
        result.z = source.z * amount;
        result.rotateX = source.rotateX * amount;
        result.rotateY = source.rotateY * amount;
        result.rotateZ = source.rotateZ * amount;
        result.scale = 1.0f + (source.scale - 1.0f) * amount;
        return result;
    }

    private static void triggerAttackOnSwing(Hand hand, PzyItemCategory category, String itemId, float swingProgress) {
        float previous = LAST_SWING.get(hand);
        if (swingProgress > 0.04f && (previous <= 0.04f || swingProgress + 0.15f < previous)) {
            PzyAnimationEngine.trigger(hand, category, itemId, "attack");
        }
        LAST_SWING.put(hand, swingProgress);
    }

    private static void addMovementTransform(PzyTransform transform, AbstractClientPlayerEntity player, Hand hand, float motionScale) {
        PzyMotionSnapshot motion = PzyMotionTracker.get();
        boolean mainHandOnRight = player.getMainArm() == Arm.RIGHT;
        float side = hand == Hand.MAIN_HAND ? (mainHandOnRight ? 1.0f : -1.0f) : (mainHandOnRight ? -1.0f : 1.0f);
        if (PzyMoveHorreClient.CONFIG.enableCustomWalk && motion.onGround && motion.moving && !motion.swimming) {
            float phase = motion.walkPhase * (motion.sprinting ? 1.35f : 1.0f);
            transform.y += (float) Math.sin(phase * 2.0f) * 0.0025f * motionScale;
            transform.rotateZ += (float) Math.cos(phase) * 1.2f * side * motionScale;
            transform.rotateX += (float) Math.sin(phase) * 0.7f * motionScale;
        }
        if (PzyMoveHorreClient.CONFIG.enableSprintArmSwing && motion.sprinting) {
            transform.rotateX += (float) Math.sin(motion.walkPhase * PzyMoveHorreClient.CONFIG.sprintArmSwingSpeed) *
                4.0f * PzyMoveHorreClient.CONFIG.sprintArmSwingIntensity * side * motionScale;
        }
        if (PzyMoveHorreClient.CONFIG.enableFallArmAnimation && motion.falling) {
            transform.rotateX += Math.min(7.0f, motion.airTime * 0.10f) * motionScale;
        }
        if (PzyMoveHorreClient.CONFIG.enableCrouchAnimation && motion.crouching) {
            transform.y -= 0.004f * motionScale;
            transform.rotateX += 1.4f * motionScale;
        }
        if (PzyMoveHorreClient.CONFIG.enableIdleSway && !motion.moving && motion.onGround && !motion.usingItem && !motion.crouching) {
            float time = motion.ageTicks;
            transform.y += (float) Math.sin(time * 0.075f + side * 0.45f) * 0.0008f * motionScale;
            transform.rotateX += (float) Math.sin(time * 0.055f + side * 0.35f) * 0.18f * motionScale;
            transform.rotateZ += (float) Math.sin(time * 0.045f + side) * 0.12f * side * motionScale;
        }
        if (PzyMoveHorreClient.CONFIG.enableCrawlAnimation && motion.crawling) transform.rotateX += 2.0f * motionScale;
        if (PzyMoveHorreClient.CONFIG.enableClimbAnimation && motion.climbing) {
            transform.rotateX += (float) Math.sin(motion.walkPhase * 2.0f) * 2.8f * side * motionScale;
        }
        if (PzyMoveHorreClient.CONFIG.enableSwimAnimation && motion.swimming) {
            transform.rotateX += (4.0f + (float) Math.sin(motion.ageTicks * 0.28f) * 2.0f) * motionScale;
        }
        if (PzyMoveHorreClient.CONFIG.enableElytraFlightAnimation && motion.gliding) transform.rotateX -= 3.0f * motionScale;
        if (PzyMoveHorreClient.CONFIG.enableBoatFirstPersonAnimations && motion.ridingBoat) transform.rotateZ += 2.0f * side * motionScale;
        if (PzyMoveHorreClient.CONFIG.enableFreezeShake && motion.frozen) {
            transform.rotateZ += (float) Math.sin(motion.ageTicks * 1.7f) * 0.45f * side * motionScale;
        }
        if (PzyMoveHorreClient.CONFIG.enableEnhancedFireEffects && motion.onFire) {
            transform.rotateX += (float) Math.sin(motion.ageTicks * 0.55f) * 0.8f * motionScale;
        }
    }
}
