package pzy.move.horre;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pzy.move.horre.animation.PzyAnimationEngine;
import pzy.move.horre.animation.PzyActionTracker;
import pzy.move.horre.config.PzyConfig;
import pzy.move.horre.gui.PzyConfigScreen;
import pzy.move.horre.input.PzyKeyBindings;
import pzy.move.horre.items.PzyItemCategory;
import pzy.move.horre.items.PzyItemClassifier;
import pzy.move.horre.motion.PzyMotionTracker;
import pzy.move.horre.packs.PzyPackManager;
import pzy.move.horre.physics.PzyPhysicsSystem;
import pzy.move.horre.profiles.PzyProfileManager;

public final class PzyMoveHorreClient implements ClientModInitializer {
    public static final String MOD_ID = "pzy_move_horre";
    public static final Logger LOGGER = LoggerFactory.getLogger("PZY MOVE HORRE");
    public static PzyConfig CONFIG = PzyConfig.defaults();

    @Override
    public void onInitializeClient() {
        CONFIG = PzyConfig.load();
        PzyPackManager.reload();
        PzyKeyBindings.register();

        ClientTickEvents.END_CLIENT_TICK.register(PzyMoveHorreClient::onClientTick);
        LOGGER.info("PZY MOVE HORRE 1.0.0 initialized — independent first-person systems loaded");
    }

    private static void onClientTick(MinecraftClient client) {
        PzyMotionTracker.tick(client);
        PzyPhysicsSystem.tick();
        PzyAnimationEngine.tick();
        PzyActionTracker.tick(client.player);

        while (PzyKeyBindings.OPEN_MENU.wasPressed()) {
            if (client.currentScreen instanceof PzyConfigScreen) client.setScreen(null);
            else client.setScreen(new PzyConfigScreen(client.currentScreen));
        }
        while (PzyKeyBindings.INSPECT.wasPressed()) {
            if (client.player != null) {
                Hand hand = client.player.isUsingItem() ? client.player.getActiveHand() : Hand.MAIN_HAND;
                PzyItemCategory category = PzyItemClassifier.classify(client.player.getStackInHand(hand));
                PzyAnimationEngine.trigger(hand, category, PzyItemClassifier.id(client.player.getStackInHand(hand)), "inspect");
            }
        }
        while (PzyKeyBindings.RELOAD_PACKS.wasPressed()) {
            PzyPackManager.reload();
            if (client.player != null) client.player.sendMessage(Text.literal("[PZY] Animation packs reloaded: " + PzyPackManager.getPacks().size()), true);
        }
    }

    public static void reloadSystems() {
        PzyPackManager.reload();
        PzyPhysicsSystem.reset();
        PzyAnimationEngine.clear();
    }
}
