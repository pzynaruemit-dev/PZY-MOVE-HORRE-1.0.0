package pzy.move.horre.packs;

import pzy.move.horre.physics.PzyTransform;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Data-only clip. Keyframes are interpolated independently for each named bone. */
public final class PzyAnimationClip {
    public String id = "unnamed";
    public float lengthTicks = 12.0f;
    public boolean loop;
    public float fadeInTicks = 3.0f;
    public float fadeOutTicks = 4.0f;
    public Map<String, List<PzyAnimationKeyframe>> bones = new LinkedHashMap<>();

    public void normalize() {
        lengthTicks = Float.isFinite(lengthTicks) ? Math.max(1.0f, Math.min(1200.0f, lengthTicks)) : 1.0f;
        fadeInTicks = Float.isFinite(fadeInTicks) ? Math.max(0.0f, Math.min(20.0f, fadeInTicks)) : 3.0f;
        fadeOutTicks = Float.isFinite(fadeOutTicks) ? Math.max(0.0f, Math.min(20.0f, fadeOutTicks)) : 4.0f;
        if (bones == null) bones = new LinkedHashMap<>();
        bones.entrySet().removeIf(entry -> entry.getKey() == null || entry.getKey().isBlank() || entry.getValue() == null);
        if (bones.size() > 64) {
            bones = bones.entrySet().stream().limit(64)
                .collect(LinkedHashMap::new, (map, entry) -> map.put(entry.getKey(), entry.getValue()), LinkedHashMap::putAll);
        }
        int remainingFrames = 4096;
        var iterator = bones.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, List<PzyAnimationKeyframe>> entry = iterator.next();
            List<PzyAnimationKeyframe> frames = entry.getValue();
            frames.removeIf(frame -> frame == null || !Float.isFinite(frame.tick));
            int allowed = Math.min(512, remainingFrames);
            if (frames.size() > allowed) frames.subList(allowed, frames.size()).clear();
            if (frames.isEmpty()) {
                iterator.remove();
                continue;
            }
            for (PzyAnimationKeyframe frame : frames) {
                frame.tick = clamp(frame.tick, 0.0f, lengthTicks, 0.0f);
                frame.x = clamp(frame.x, -2.0f, 2.0f, 0.0f);
                frame.y = clamp(frame.y, -2.0f, 2.0f, 0.0f);
                frame.z = clamp(frame.z, -2.0f, 2.0f, 0.0f);
                frame.rotateX = clamp(frame.rotateX, -3600.0f, 3600.0f, 0.0f);
                frame.rotateY = clamp(frame.rotateY, -3600.0f, 3600.0f, 0.0f);
                frame.rotateZ = clamp(frame.rotateZ, -3600.0f, 3600.0f, 0.0f);
                frame.scale = clamp(frame.scale, 0.05f, 4.0f, 1.0f);
            }
            frames.sort(Comparator.comparingDouble(frame -> frame.tick));
            remainingFrames -= frames.size();
            if (remainingFrames <= 0) {
                while (iterator.hasNext()) {
                    iterator.next();
                    iterator.remove();
                }
                break;
            }
        }
    }

    private static float clamp(float value, float min, float max, float fallback) {
        if (!Float.isFinite(value)) return fallback;
        return Math.max(min, Math.min(max, value));
    }

    public PzyTransform sample(String bone, float tick) {
        if (bone == null || !Float.isFinite(tick)) return new PzyTransform();
        List<PzyAnimationKeyframe> frames = bones.get(bone);
        if (frames == null || frames.isEmpty()) return new PzyTransform();
        float t = loop ? positiveModulo(tick, lengthTicks) : Math.max(0, Math.min(lengthTicks, tick));
        if (frames.size() == 1 || t <= frames.get(0).tick) return toTransform(frames.get(0));
        for (int i = 0; i < frames.size() - 1; i++) {
            PzyAnimationKeyframe a = frames.get(i);
            PzyAnimationKeyframe b = frames.get(i + 1);
            if (t <= b.tick) {
                float span = Math.max(0.0001f, b.tick - a.tick);
                float alpha = Math.max(0, Math.min(1, (t - a.tick) / span));
                alpha = alpha * alpha * (3.0f - 2.0f * alpha);
                return interpolate(a, b, alpha);
            }
        }
        return toTransform(frames.get(frames.size() - 1));
    }

    private static PzyTransform toTransform(PzyAnimationKeyframe frame) {
        PzyTransform result = new PzyTransform();
        result.x = frame.x; result.y = frame.y; result.z = frame.z;
        result.rotateX = frame.rotateX; result.rotateY = frame.rotateY; result.rotateZ = frame.rotateZ;
        result.scale = frame.scale;
        return result;
    }

    private static PzyTransform interpolate(PzyAnimationKeyframe a, PzyAnimationKeyframe b, float t) {
        PzyTransform result = new PzyTransform();
        result.x = lerp(a.x, b.x, t); result.y = lerp(a.y, b.y, t); result.z = lerp(a.z, b.z, t);
        result.rotateX = lerpAngle(a.rotateX, b.rotateX, t); result.rotateY = lerpAngle(a.rotateY, b.rotateY, t);
        result.rotateZ = lerpAngle(a.rotateZ, b.rotateZ, t); result.scale = lerp(a.scale, b.scale, t);
        return result;
    }

    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    private static float lerpAngle(float a, float b, float t) {
        float delta = ((b - a + 540.0f) % 360.0f) - 180.0f;
        return a + delta * t;
    }
    private static float positiveModulo(float value, float modulus) {
        if (!Float.isFinite(modulus) || modulus <= 0) return 0;
        float result = value % modulus;
        return result < 0 ? result + modulus : result;
    }
}
