package pzy.move.horre.packs;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Public manifest schema for independent PZY animation packs. */
public final class PzyPackManifest {
    public int schema = 1;
    public String id = "pzy:unnamed";
    public String name = "Unnamed PZY Pack";
    public String author = "Unknown";
    public String version = "1.0.0";
    public String description = "";
    public int priority = 0;
    public boolean enabled = true;
    public Map<String, String> clips = new LinkedHashMap<>();
    public List<PzyPackRule> rules = new ArrayList<>();
}
