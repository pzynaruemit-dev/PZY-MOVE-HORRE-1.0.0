package pzy.move.horre.packs;

import java.util.LinkedHashMap;
import java.util.Map;

/** One item/category match and its action-to-clip bindings in a PZY pack. */
public final class PzyPackRule {
    public String selector = "*";
    public String category = "";
    /** BOTH, MAIN or OFF; omitted values default to BOTH. */
    public String hand = "BOTH";
    public Map<String, String> actions = new LinkedHashMap<>();
}
