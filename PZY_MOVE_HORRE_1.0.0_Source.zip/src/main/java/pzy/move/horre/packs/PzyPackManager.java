package pzy.move.horre.packs;

import com.google.gson.Gson;
import net.fabricmc.loader.api.FabricLoader;
import pzy.move.horre.PzyMoveHorreClient;
import pzy.move.horre.config.PzyConfig;
import pzy.move.horre.items.PzyGlob;
import pzy.move.horre.items.PzyItemCategory;
import net.minecraft.util.Hand;

import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Loads PZY packs from config/pzy_move_horre/packs (folders or ZIP files). */
public final class PzyPackManager {
    private static final Gson GSON = PzyConfig.GSON;
    private static final long MAX_JSON_BYTES = 2L * 1024L * 1024L;
    private static final long MAX_PACK_BYTES = 8L * 1024L * 1024L;
    private static final int MAX_PACKS = 32;
    private static final int MAX_CLIPS_PER_PACK = 256;
    private static final Path PACK_DIR = FabricLoader.getInstance().getConfigDir().resolve("pzy_move_horre").resolve("packs");
    private static final Map<String, PzyLoadedPack> PACKS = new LinkedHashMap<>();

    private PzyPackManager() { }

    public static synchronized void reload() {
        PACKS.clear();
        boolean configChanged = false;
        PzyPackManifest builtIn = new PzyPackManifest();
        builtIn.id = "pzy:default";
        builtIn.name = "PZY Default";
        builtIn.author = "PZY";
        builtIn.description = "Built-in pack slot. Animation clips are added in the animation development phase.";
        PACKS.put(builtIn.id, new PzyLoadedPack(builtIn, "built-in"));
        try {
            Files.createDirectories(PACK_DIR);
            try (var paths = Files.list(PACK_DIR)) {
                for (Path path : paths.sorted().toList()) {
                    if (PACKS.size() >= MAX_PACKS + 1) {
                        PzyMoveHorreClient.LOGGER.warn("PZY pack limit reached ({}); remaining packs skipped", MAX_PACKS);
                        break;
                    }
                    int before = PACKS.size();
                    loadPath(path);
                    if (PACKS.size() > before) {
                        PzyLoadedPack newest = PACKS.values().stream().reduce((first, second) -> second).orElse(null);
                        if (newest != null && !PzyMoveHorreClient.CONFIG.packEnabled.containsKey(newest.manifest.id)) {
                            PzyMoveHorreClient.CONFIG.packEnabled.put(newest.manifest.id, newest.manifest.enabled);
                            configChanged = true;
                        }
                    }
                }
            }
        } catch (IOException exception) {
            PzyMoveHorreClient.LOGGER.error("Could not scan PZY animation packs", exception);
        }
        if (configChanged) PzyMoveHorreClient.CONFIG.save();
    }

    private static void loadPath(Path path) {
        try {
            if (Files.isSymbolicLink(path)) return;
            if (Files.isDirectory(path)) loadDirectory(path);
            else if (path.getFileName().toString().toLowerCase().endsWith(".zip")) loadZip(path);
        } catch (Exception exception) {
            PzyMoveHorreClient.LOGGER.warn("Skipped invalid PZY pack {}: {}", path.getFileName(), exception.getMessage());
        }
    }

    private static void loadDirectory(Path directory) throws IOException {
        Path base = directory.toRealPath();
        Path manifestFile = base.resolve("pzy_pack.json").normalize();
        if (!manifestFile.startsWith(base) || !Files.isRegularFile(manifestFile)) return;
        Path manifestReal = manifestFile.toRealPath();
        if (!manifestReal.startsWith(base) || Files.size(manifestReal) > MAX_JSON_BYTES || Files.size(manifestReal) > MAX_PACK_BYTES) return;
        long packBytes = Files.size(manifestReal);
        try (var reader = Files.newBufferedReader(manifestReal, StandardCharsets.UTF_8)) {
            PzyPackManifest manifest = GSON.fromJson(reader, PzyPackManifest.class);
            PzyLoadedPack pack = validateManifest(manifest, directory.toString());
            if (pack == null) return;
            int clipCount = 0;
            for (Map.Entry<String, String> entry : pack.manifest.clips.entrySet()) {
                if (clipCount++ >= MAX_CLIPS_PER_PACK) break;
                if (entry.getKey() == null || entry.getValue() == null || entry.getValue().isBlank()) continue;
                Path clipFile = base.resolve(entry.getValue()).normalize();
                if (!clipFile.startsWith(base) || !Files.isRegularFile(clipFile)) continue;
                Path clipReal = clipFile.toRealPath();
                if (!clipReal.startsWith(base)) continue;
                long clipBytes = Files.size(clipReal);
                if (clipBytes > MAX_JSON_BYTES || packBytes + clipBytes > MAX_PACK_BYTES) continue;
                packBytes += clipBytes;
                try (var clipReader = Files.newBufferedReader(clipReal, StandardCharsets.UTF_8)) {
                    PzyAnimationClip clip = GSON.fromJson(clipReader, PzyAnimationClip.class);
                    if (clip != null) { clip.normalize(); pack.clips.put(entry.getKey(), clip); }
                }
            }
            registerPack(pack);
        }
    }

    private static void loadZip(Path file) throws IOException {
        try (ZipFile zip = new ZipFile(file.toFile())) {
            ZipEntry manifestEntry = zip.getEntry("pzy_pack.json");
            if (manifestEntry == null || manifestEntry.getSize() < 0 || manifestEntry.getSize() > MAX_JSON_BYTES || manifestEntry.getSize() > MAX_PACK_BYTES) return;
            long packBytes = manifestEntry.getSize();
            PzyPackManifest manifest;
            try (var reader = new InputStreamReader(zip.getInputStream(manifestEntry), StandardCharsets.UTF_8)) {
                manifest = GSON.fromJson(reader, PzyPackManifest.class);
            }
            PzyLoadedPack pack = validateManifest(manifest, file.toString());
            if (pack == null) return;
            int clipCount = 0;
            for (Map.Entry<String, String> entry : pack.manifest.clips.entrySet()) {
                if (clipCount++ >= MAX_CLIPS_PER_PACK) break;
                if (entry.getKey() == null || entry.getValue() == null || entry.getValue().isBlank()) continue;
                String clipPath = entry.getValue().replace('\\', '/');
                java.nio.file.Path normalized = java.nio.file.Path.of(clipPath).normalize();
                if (clipPath.startsWith("/") || normalized.isAbsolute() || java.util.Arrays.asList(clipPath.split("/")).contains("..")) continue;
                ZipEntry clipEntry = zip.getEntry(clipPath);
                if (clipEntry == null || clipEntry.isDirectory() || clipEntry.getSize() < 0 || clipEntry.getSize() > MAX_JSON_BYTES) continue;
                if (packBytes + clipEntry.getSize() > MAX_PACK_BYTES) continue;
                packBytes += clipEntry.getSize();
                try (var reader = new InputStreamReader(zip.getInputStream(clipEntry), StandardCharsets.UTF_8)) {
                    PzyAnimationClip clip = GSON.fromJson(reader, PzyAnimationClip.class);
                    if (clip != null) { clip.normalize(); pack.clips.put(entry.getKey(), clip); }
                }
            }
            registerPack(pack);
        }
    }

    private static void registerPack(PzyLoadedPack pack) {
        String id = pack.manifest.id;
        if ("pzy:default".equals(id) || PACKS.containsKey(id)) {
            PzyMoveHorreClient.LOGGER.warn("Ignored duplicate or reserved PZY pack id {}", id);
            return;
        }
        PACKS.put(id, pack);
    }

    private static PzyLoadedPack validateManifest(PzyPackManifest manifest, String source) {
        if (manifest == null || manifest.id == null || !manifest.id.matches("[a-z0-9_.-]+:[a-z0-9/_.-]+")) return null;
        if (manifest.schema != 1) {
            PzyMoveHorreClient.LOGGER.warn("Unsupported PZY pack schema {} in {}", manifest.schema, source);
            return null;
        }
        if (manifest.name == null || manifest.name.isBlank()) manifest.name = manifest.id;
        if (manifest.author == null) manifest.author = "Unknown";
        if (manifest.clips == null) manifest.clips = new LinkedHashMap<>();
        if (manifest.rules == null) manifest.rules = new ArrayList<>();
        if (manifest.clips.size() > MAX_CLIPS_PER_PACK) {
            manifest.clips = manifest.clips.entrySet().stream().limit(MAX_CLIPS_PER_PACK)
                .collect(LinkedHashMap::new, (map, entry) -> map.put(entry.getKey(), entry.getValue()), LinkedHashMap::putAll);
        }
        if (manifest.rules.size() > 512) manifest.rules = manifest.rules.subList(0, 512);
        return new PzyLoadedPack(manifest, source);
    }

    public static synchronized List<PzyLoadedPack> getPacks() {
        return PACKS.values().stream().sorted(Comparator.comparingInt(pack -> -pack.manifest.priority)).toList();
    }

    public static synchronized PzyLoadedPack get(String id) { return PACKS.get(id); }

    public static synchronized PzyAnimationClip findClip(PzyItemCategory category, String itemId, String action, Hand hand) {
        PzyConfig config = PzyMoveHorreClient.CONFIG;
        String selected = config.packChoices.getOrDefault(category.name(), config.packChoices.getOrDefault("DEFAULT", "pzy:default"));
        PzyLoadedPack pack = PACKS.get(selected);
        if (pack == null || !isEnabled(pack.manifest.id)) {
            selected = config.packChoices.getOrDefault("DEFAULT", "pzy:default");
            pack = PACKS.get(selected);
        }
        if (pack == null || !isEnabled(pack.manifest.id)) return null;
        for (PzyPackRule rule : pack.manifest.rules) {
            if (rule == null || rule.actions == null) continue;
            boolean categoryMatch = rule.category == null || rule.category.isBlank() || rule.category.equalsIgnoreCase(category.name());
            boolean itemMatch = rule.selector == null || rule.selector.isBlank() || PzyGlob.matches(rule.selector, itemId);
            boolean handMatch = rule.hand == null || rule.hand.isBlank() || rule.hand.equalsIgnoreCase("BOTH") ||
                (hand == Hand.MAIN_HAND && rule.hand.equalsIgnoreCase("MAIN")) ||
                (hand == Hand.OFF_HAND && rule.hand.equalsIgnoreCase("OFF"));
            if (categoryMatch && itemMatch && handMatch) {
                String clipId = rule.actions.get(action);
                if (clipId != null) return pack.clips.get(clipId);
            }
        }
        return null;
    }

    public static synchronized boolean isEnabled(String id) {
        if ("pzy:default".equals(id)) return true;
        PzyLoadedPack pack = PACKS.get(id);
        if (pack == null) return false;
        return PzyMoveHorreClient.CONFIG.packEnabled.getOrDefault(id, pack.manifest.enabled);
    }

    public static synchronized void setEnabled(String id, boolean enabled) {
        if ("pzy:default".equals(id)) return;
        if (!PACKS.containsKey(id)) return;
        PzyMoveHorreClient.CONFIG.packEnabled.put(id, enabled);
        PzyMoveHorreClient.CONFIG.save();
    }

    public static Path getPackDirectory() { return PACK_DIR; }
}
