package pzy.move.horre.packs;

public final class PzyAnimationKeyframe {
    public float tick;
    public float x, y, z;
    public float rotateX, rotateY, rotateZ;
    public float scale = 1.0f;
}
