package pzy.move.horre.packs;

import java.util.LinkedHashMap;
import java.util.Map;

public final class PzyLoadedPack {
    public final PzyPackManifest manifest;
    public final Map<String, PzyAnimationClip> clips = new LinkedHashMap<>();
    public final String source;

    public PzyLoadedPack(PzyPackManifest manifest, String source) {
        this.manifest = manifest;
        this.source = source;
    }
}
