package pzy.move.horre.animation;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.UseAction;
import pzy.move.horre.items.PzyItemCategory;
import pzy.move.horre.items.PzyItemClassifier;

import java.util.EnumMap;
import java.util.Map;

/** Converts vanilla hand/item state changes into stable PZY action events. */
public final class PzyActionTracker {
    private static final Map<Hand, String> LAST_ITEM_ID = new EnumMap<>(Hand.class);
    private static final Map<Hand, ItemStack> LAST_STACK = new EnumMap<>(Hand.class);
    private static final Map<Hand, ItemStack> ACTIVE_USE_STACK = new EnumMap<>(Hand.class);
    private static final Map<Hand, Boolean> WAS_USING = new EnumMap<>(Hand.class);

    static {
        for (Hand hand : Hand.values()) {
            LAST_ITEM_ID.put(hand, "");
            LAST_STACK.put(hand, ItemStack.EMPTY);
            ACTIVE_USE_STACK.put(hand, ItemStack.EMPTY);
            WAS_USING.put(hand, false);
        }
    }

    private PzyActionTracker() { }

    public static void tick(ClientPlayerEntity player) {
        if (player == null) {
            reset();
            return;
        }
        for (Hand hand : Hand.values()) {
            ItemStack stack = player.getStackInHand(hand);
            String itemId = PzyItemClassifier.id(stack);
            String previousId = LAST_ITEM_ID.get(hand);
            ItemStack previousStack = LAST_STACK.get(hand);
            if (!itemId.equals(previousId)) {
                if (!previousId.isEmpty()) {
                    if ("minecraft:air".equals(itemId) && !previousStack.isEmpty()) {
                        PzyAnimationEngine.trigger(hand, PzyItemClassifier.classify(previousStack),
                            PzyItemClassifier.id(previousStack), "unequip");
                    } else if (!"minecraft:air".equals(itemId)) {
                        PzyAnimationEngine.trigger(hand, PzyItemClassifier.classify(stack), itemId, "equip");
                    }
                }
                LAST_ITEM_ID.put(hand, itemId);
                LAST_STACK.put(hand, stack.isEmpty() ? ItemStack.EMPTY : stack.copy());
            }

            boolean using = player.isUsingItem() && player.getActiveHand() == hand;
            if (using && !WAS_USING.get(hand)) {
                ItemStack active = stack.isEmpty() ? ItemStack.EMPTY : stack.copy();
                ACTIVE_USE_STACK.put(hand, active);
                PzyAnimationEngine.trigger(hand, PzyItemClassifier.classify(stack), itemId, getUseAction(stack));
            } else if (!using && WAS_USING.get(hand)) {
                ItemStack used = ACTIVE_USE_STACK.get(hand);
                if (used != null && !used.isEmpty()) {
                    PzyAnimationEngine.trigger(hand, PzyItemClassifier.classify(used), PzyItemClassifier.id(used), "release");
                }
                ACTIVE_USE_STACK.put(hand, ItemStack.EMPTY);
            }
            WAS_USING.put(hand, using);
        }
    }

    public static void triggerCurrentHand(Hand hand, String action) {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (player == null || hand == null || action == null || action.isBlank()) return;
        ItemStack stack = player.getStackInHand(hand);
        PzyAnimationEngine.trigger(hand, PzyItemClassifier.classify(stack), PzyItemClassifier.id(stack), action);
    }

    private static String getUseAction(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return "use";
        UseAction action = stack.getItem().getUseAction(stack);
        return switch (action.name()) {
            case "EAT" -> "eat";
            case "DRINK" -> "drink";
            case "BLOCK" -> "block";
            case "BOW" -> "bow_draw";
            case "CROSSBOW" -> "crossbow_load";
            case "SPEAR" -> "spear_charge";
            case "SPYGLASS" -> "spyglass";
            case "TOOT_HORN" -> "horn";
            case "BRUSH" -> "brush";
            default -> "use";
        };
    }

    public static void reset() {
        for (Hand hand : Hand.values()) {
            LAST_ITEM_ID.put(hand, "");
            LAST_STACK.put(hand, ItemStack.EMPTY);
            ACTIVE_USE_STACK.put(hand, ItemStack.EMPTY);
            WAS_USING.put(hand, false);
        }
    }
}
