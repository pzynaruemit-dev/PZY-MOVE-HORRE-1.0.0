package pzy.move.horre.animation;

import net.minecraft.util.Hand;
import pzy.move.horre.PzyMoveHorreClient;
import pzy.move.horre.items.PzyItemCategory;
import pzy.move.horre.packs.PzyAnimationClip;
import pzy.move.horre.packs.PzyPackManager;
import pzy.move.horre.physics.PzyTransform;

import java.util.EnumMap;
import java.util.Map;

/** Per-hand clip playback with action replacement and fade blending. */
public final class PzyAnimationEngine {
    private static final Map<Hand, Playback> ACTIVE = new EnumMap<>(Hand.class);
    private static long clientTick;

    private PzyAnimationEngine() { }

    public static void tick() { clientTick++; }

    public static void trigger(Hand hand, PzyItemCategory category, String itemId, String action) {
        if (hand == null || category == null || itemId == null || action == null || action.isBlank()) return;
        PzyAnimationClip clip = PzyPackManager.findClip(category, itemId, action, hand);
        if (clip == null) return;
        clip.normalize();
        float speed = PzyMoveHorreClient.CONFIG.animationSpeed *
            PzyMoveHorreClient.CONFIG.categoryAnimationSpeeds.getOrDefault(category.name(), 1.0f);
        speed = Float.isFinite(speed) ? Math.max(0.1f, Math.min(4.0f, speed)) : 1.0f;
        Playback previous = ACTIVE.get(hand);
        if (previous != null) previous = previous.snapshot();
        ACTIVE.put(hand, new Playback(clip, clientTick, speed, previous));
    }

    public static PzyTransform sample(Hand hand, String bone, float tickDelta) {
        Playback playback = ACTIVE.get(hand);
        if (playback == null || bone == null) return new PzyTransform();
        float elapsed = Math.max(0.0f, ((clientTick - playback.startedAt) + tickDelta) * playback.speed);
        if (!playback.clip.loop && elapsed >= playback.clip.lengthTicks + playback.clip.fadeOutTicks) {
            ACTIVE.remove(hand);
            return new PzyTransform();
        }

        PzyTransform current = samplePlayback(playback, hand, bone, elapsed);
        float fade = playback.clip.fadeInTicks <= 0.0f ? 1.0f : clamp(elapsed / playback.clip.fadeInTicks);
        PzyTransform previous = playback.previous == null
            ? new PzyTransform()
            : samplePlaybackAt(playback.previous, hand, bone, clientTick + tickDelta);
        return blend(previous, current, fade);
    }

    private static PzyTransform samplePlaybackAt(Playback playback, Hand hand, String bone, float absoluteTick) {
        float elapsed = Math.max(0.0f, (absoluteTick - playback.startedAt) * playback.speed);
        return samplePlayback(playback, hand, bone, elapsed);
    }

    private static PzyTransform samplePlayback(Playback playback, Hand hand, String bone, float elapsed) {
        float sampleTick = playback.clip.loop
            ? elapsed
            : Math.min(playback.clip.lengthTicks, elapsed);
        String specificBone = hand == Hand.MAIN_HAND ? "main_" + bone : "off_" + bone;
        String resolvedBone = playback.clip.bones.containsKey(specificBone) ? specificBone : bone;
        PzyTransform pose = playback.clip.sample(resolvedBone, sampleTick);
        if (!playback.clip.loop && elapsed > playback.clip.lengthTicks) {
            float fadeOut = playback.clip.fadeOutTicks <= 0.0f ? 0.0f :
                1.0f - clamp((elapsed - playback.clip.lengthTicks) / playback.clip.fadeOutTicks);
            return blend(new PzyTransform(), pose, fadeOut);
        }
        return pose;
    }

    private static PzyTransform blend(PzyTransform from, PzyTransform to, float alpha) {
        float t = clamp(alpha);
        PzyTransform result = new PzyTransform();
        result.x = lerp(from.x, to.x, t);
        result.y = lerp(from.y, to.y, t);
        result.z = lerp(from.z, to.z, t);
        result.rotateX = lerp(from.rotateX, to.rotateX, t);
        result.rotateY = lerp(from.rotateY, to.rotateY, t);
        result.rotateZ = lerp(from.rotateZ, to.rotateZ, t);
        result.scale = lerp(from.scale, to.scale, t);
        return result;
    }

    private static float clamp(float value) { return Math.max(0.0f, Math.min(1.0f, value)); }
    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }

    public static void clear() { ACTIVE.clear(); clientTick = 0; }

    private record Playback(PzyAnimationClip clip, long startedAt, float speed, Playback previous) {
        private Playback snapshot() {
            return new Playback(clip, startedAt, speed, null);
        }
    }
}
