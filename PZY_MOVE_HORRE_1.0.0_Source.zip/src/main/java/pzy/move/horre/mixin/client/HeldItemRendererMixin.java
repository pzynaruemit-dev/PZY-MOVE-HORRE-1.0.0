package pzy.move.horre.mixin.client;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pzy.move.horre.PzyMoveHorreClient;
import pzy.move.horre.compat.PzyCompatManager;
import pzy.move.horre.render.PzyHandRenderer;
import pzy.move.horre.render.PzyRenderContext;

@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    @Shadow private float equipProgressOffHand;

    @Shadow
    private void renderArmHoldingItem(MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                                      int light, float equipProgress, float swingProgress, Arm arm) {
        throw new AssertionError("PZY mixin shadow was not transformed");
    }

    @Inject(
        method = "renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
        at = @At("HEAD")
    )
    private void pzy$beforeFirstPersonHand(AbstractClientPlayerEntity player, float tickDelta, float pitch,
                                           Hand hand, float swingProgress, ItemStack item, float equipProgress,
                                           MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                                           int light, CallbackInfo ci) {
        PzyRenderContext.begin(hand, item, tickDelta);
        matrices.push();
        PzyHandRenderer.apply(player, tickDelta, hand, swingProgress, item, matrices);
    }

    @Inject(
        method = "renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
        at = @At("RETURN")
    )
    private void pzy$afterFirstPersonHand(AbstractClientPlayerEntity player, float tickDelta, float pitch,
                                          Hand hand, float swingProgress, ItemStack item, float equipProgress,
                                          MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                                          int light, CallbackInfo ci) {
        matrices.pop();
        PzyRenderContext.end();
    }

    @Inject(
        method = "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;Lnet/minecraft/client/network/ClientPlayerEntity;I)V",
        at = @At("TAIL")
    )
    private void pzy$renderEmptyOffhand(float tickDelta, MatrixStack matrices,
                                        VertexConsumerProvider.Immediate vertexConsumers,
                                        ClientPlayerEntity player, int light, CallbackInfo ci) {
        if (!PzyMoveHorreClient.CONFIG.enabled || !PzyMoveHorreClient.CONFIG.showBothHands ||
            PzyCompatManager.shouldDeferToExternalFirstPersonModel()) return;
        if (!player.getOffHandStack().isEmpty() || player.isInvisible()) return;
        matrices.push();
        PzyHandRenderer.apply(player, tickDelta, Hand.OFF_HAND, 0.0f, ItemStack.EMPTY, matrices);
        renderArmHoldingItem(matrices, vertexConsumers, light, equipProgressOffHand, 0.0f,
            player.getMainArm().getOpposite());
        matrices.pop();
    }
}
