package pzy.move.horre.mixin.client;

import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ModelTransformationMode;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pzy.move.horre.render.PzyHandRenderer;
import pzy.move.horre.render.PzyRenderContext;

@Mixin(ItemRenderer.class)
public abstract class ItemRendererMixin {
    @Inject(
        method = "renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ModelTransformationMode;ZLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/world/World;III)V",
        at = @At("HEAD")
    )
    private void pzy$beforeFirstPersonItem(LivingEntity entity, ItemStack stack, ModelTransformationMode mode,
                                           boolean leftHanded, MatrixStack matrices,
                                           VertexConsumerProvider consumers, World world,
                                           int light, int overlay, int seed, CallbackInfo ci) {
        PzyRenderContext.Entry entry = PzyRenderContext.current();
        if (entry == null || !entry.matches(stack)) return;
        matrices.push();
        PzyHandRenderer.applyItem(entry.hand(), entry.tickDelta(), stack, matrices);
    }

    @Inject(
        method = "renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ModelTransformationMode;ZLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/world/World;III)V",
        at = @At("RETURN")
    )
    private void pzy$afterFirstPersonItem(LivingEntity entity, ItemStack stack, ModelTransformationMode mode,
                                          boolean leftHanded, MatrixStack matrices,
                                          VertexConsumerProvider consumers, World world,
                                          int light, int overlay, int seed, CallbackInfo ci) {
        PzyRenderContext.Entry entry = PzyRenderContext.current();
        if (entry != null && entry.matches(stack)) matrices.pop();
    }
}
