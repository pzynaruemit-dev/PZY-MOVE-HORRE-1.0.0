package pzy.move.horre.motion;

/** Immutable movement sample shared by render, animation and physics systems. */
public final class PzyMotionSnapshot {
    public float horizontalSpeed;
    public float verticalSpeed;
    public float accelerationX;
    public float accelerationZ;
    public float yawDelta;
    public float pitchDelta;
    public float walkPhase;
    public float airTime;
    public long ageTicks;
    public boolean moving;
    public boolean sprinting;
    public boolean crouching;
    public boolean onGround;
    public boolean falling;
    public boolean climbing;
    public boolean swimming;
    public boolean crawling;
    public boolean gliding;
    public boolean ridingBoat;
    public boolean usingItem;
    public boolean frozen;
    public boolean onFire;
}
