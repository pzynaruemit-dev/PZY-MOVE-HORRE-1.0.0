package pzy.move.horre.motion;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.Vec3d;

/** Samples actual player movement and camera rotation once per client tick. */
public final class PzyMotionTracker {
    private static final PzyMotionSnapshot SNAPSHOT = new PzyMotionSnapshot();
    private static double previousVelocityX;
    private static double previousVelocityZ;
    private static float previousYaw;
    private static float previousPitch;
    private static boolean initialized;

    private PzyMotionTracker() { }

    public static void tick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null) {
            reset();
            return;
        }

        SNAPSHOT.ageTicks++;
        Vec3d velocity = player.getVelocity();
        double vx = velocity.x;
        double vz = velocity.z;
        SNAPSHOT.horizontalSpeed = (float) Math.sqrt(vx * vx + vz * vz);
        SNAPSHOT.verticalSpeed = (float) velocity.y;
        SNAPSHOT.moving = SNAPSHOT.horizontalSpeed > 0.015f;
        SNAPSHOT.sprinting = player.isSprinting();
        SNAPSHOT.crouching = player.isSneaking();
        SNAPSHOT.onGround = player.isOnGround();
        SNAPSHOT.falling = !SNAPSHOT.onGround && velocity.y < -0.06;
        SNAPSHOT.climbing = player.isClimbing();
        SNAPSHOT.swimming = player.isSwimming() || player.isInLava();
        SNAPSHOT.crawling = player.isCrawling();
        SNAPSHOT.gliding = player.isFallFlying();
        SNAPSHOT.usingItem = player.isUsingItem();
        SNAPSHOT.frozen = player.isFrozen();
        SNAPSHOT.onFire = player.isOnFire();

        if (player.getVehicle() != null) {
            String vehicleId = Registries.ENTITY_TYPE.getId(player.getVehicle().getType()).getPath();
            SNAPSHOT.ridingBoat = vehicleId.contains("boat") || vehicleId.contains("raft");
        } else {
            SNAPSHOT.ridingBoat = false;
        }

        if (!initialized) {
            previousVelocityX = vx;
            previousVelocityZ = vz;
            previousYaw = player.getYaw();
            previousPitch = player.getPitch();
            initialized = true;
        }

        SNAPSHOT.accelerationX = (float) (vx - previousVelocityX);
        SNAPSHOT.accelerationZ = (float) (vz - previousVelocityZ);
        SNAPSHOT.yawDelta = wrapDegrees(player.getYaw() - previousYaw);
        SNAPSHOT.pitchDelta = player.getPitch() - previousPitch;
        previousVelocityX = vx;
        previousVelocityZ = vz;
        previousYaw = player.getYaw();
        previousPitch = player.getPitch();

        if (SNAPSHOT.onGround && SNAPSHOT.moving) {
            SNAPSHOT.walkPhase += SNAPSHOT.horizontalSpeed * (SNAPSHOT.sprinting ? 1.55f : 1.0f);
        }
        SNAPSHOT.airTime = SNAPSHOT.falling ? SNAPSHOT.airTime + 1.0f : 0.0f;
    }

    public static PzyMotionSnapshot get() {
        return SNAPSHOT;
    }

    private static float wrapDegrees(float value) {
        value %= 360.0f;
        if (value >= 180.0f) value -= 360.0f;
        if (value < -180.0f) value += 360.0f;
        return value;
    }

    private static void reset() {
        SNAPSHOT.horizontalSpeed = 0;
        SNAPSHOT.verticalSpeed = 0;
        SNAPSHOT.accelerationX = 0;
        SNAPSHOT.accelerationZ = 0;
        SNAPSHOT.yawDelta = 0;
        SNAPSHOT.pitchDelta = 0;
        SNAPSHOT.walkPhase = 0;
        SNAPSHOT.airTime = 0;
        SNAPSHOT.ageTicks = 0;
        SNAPSHOT.moving = false;
        SNAPSHOT.sprinting = false;
        SNAPSHOT.crouching = false;
        SNAPSHOT.onGround = true;
        SNAPSHOT.falling = false;
        SNAPSHOT.climbing = false;
        SNAPSHOT.swimming = false;
        SNAPSHOT.crawling = false;
        SNAPSHOT.gliding = false;
        SNAPSHOT.ridingBoat = false;
        SNAPSHOT.usingItem = false;
        SNAPSHOT.frozen = false;
        SNAPSHOT.onFire = false;
        initialized = false;
    }
}
