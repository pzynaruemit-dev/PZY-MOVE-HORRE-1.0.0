package pzy.move.horre.compat;

import net.fabricmc.loader.api.FabricLoader;

import java.util.LinkedHashMap;
import java.util.Map;

/** Detects known first-person/animation integrations without hard-linking to them. */
public final class PzyCompatManager {
    private static final Map<String, String> KNOWN = new LinkedHashMap<>();
    static {
        KNOWN.put("bettercombat", "Better Combat");
        KNOWN.put("epicfight", "Epic Fight");
        KNOWN.put("irons_spellbooks", "Iron's Spells 'n Spellbooks");
        KNOWN.put("spell_engine", "Spell Engine");
        KNOWN.put("carryon", "Carry On");
        KNOWN.put("firstperson", "First Person Model");
        KNOWN.put("spatialgui", "Spatial GUI");
        KNOWN.put("interactivestuff", "Interactive Stuff");
        KNOWN.put("tacz", "Timeless and Classics Zero");
        KNOWN.put("figura", "Figura");
    }

    private PzyCompatManager() { }

    public static boolean isInstalled(String modId) {
        return FabricLoader.getInstance().isModLoaded(modId);
    }

    public static Map<String, Boolean> getDetectedMods() {
        Map<String, Boolean> detected = new LinkedHashMap<>();
        KNOWN.forEach((id, name) -> detected.put(name, isInstalled(id)));
        return detected;
    }

    public static boolean shouldDeferToExternalFirstPersonModel() {
        return pzy.move.horre.PzyMoveHorreClient.CONFIG.firstPersonModelAutoHide && isInstalled("firstperson");
    }

    public static String debugSummary() {
        StringBuilder builder = new StringBuilder("PZY compatibility scan:");
        getDetectedMods().forEach((name, present) -> builder.append("\n- ").append(name).append(": ").append(present ? "installed" : "not installed"));
        return builder.toString();
    }
}
