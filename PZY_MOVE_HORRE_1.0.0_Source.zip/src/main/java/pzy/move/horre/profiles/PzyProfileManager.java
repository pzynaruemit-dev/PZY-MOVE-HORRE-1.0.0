package pzy.move.horre.profiles;

import net.fabricmc.loader.api.FabricLoader;
import pzy.move.horre.PzyMoveHorreClient;
import pzy.move.horre.config.PzyConfig;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/** Named presets for settings, blacklist entries, pack choices and hand editor poses. */
public final class PzyProfileManager {
    private static final Path PROFILE_DIR = FabricLoader.getInstance().getConfigDir().resolve("pzy_move_horre").resolve("profiles");
    private static final Pattern SAFE_NAME = Pattern.compile("[a-zA-Z0-9 _.-]{1,32}");

    private PzyProfileManager() { }

    public static boolean save(String name) {
        String safe = normalize(name);
        if (safe == null) return false;
        try {
            Files.createDirectories(PROFILE_DIR);
            PzyConfig snapshot = PzyMoveHorreClient.CONFIG.copy();
            snapshot.activeProfile = safe;
            Path destination = PROFILE_DIR.resolve(fileName(safe));
            Path temporary = PROFILE_DIR.resolve(fileName(safe) + ".tmp");
            Files.writeString(temporary, PzyConfig.GSON.toJson(snapshot), StandardCharsets.UTF_8);
            try {
                Files.move(temporary, destination, java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (java.nio.file.AtomicMoveNotSupportedException ignored) {
                Files.move(temporary, destination, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
            PzyMoveHorreClient.CONFIG.activeProfile = safe;
            PzyMoveHorreClient.CONFIG.save();
            return true;
        } catch (IOException exception) {
            PzyMoveHorreClient.LOGGER.error("Could not save PZY profile {}", safe, exception);
            return false;
        }
    }

    public static boolean load(String name) {
        String safe = normalize(name);
        if (safe == null) return false;
        Path path = PROFILE_DIR.resolve(fileName(safe));
        if (!Files.isRegularFile(path)) return false;
        try {
            PzyConfig loaded = PzyConfig.fromJson(Files.readString(path, StandardCharsets.UTF_8));
            if (loaded == null) return false;
            loaded.activeProfile = safe;
            PzyMoveHorreClient.CONFIG = loaded;
            PzyMoveHorreClient.CONFIG.save();
            PzyMoveHorreClient.reloadSystems();
            return true;
        } catch (Exception exception) {
            PzyMoveHorreClient.LOGGER.error("Could not load PZY profile {}", safe, exception);
            return false;
        }
    }

    public static boolean delete(String name) {
        String safe = normalize(name);
        if (safe == null) return false;
        try {
            boolean deleted = Files.deleteIfExists(PROFILE_DIR.resolve(fileName(safe)));
            if (deleted && PzyMoveHorreClient.CONFIG.activeProfile.equalsIgnoreCase(safe)) {
                PzyMoveHorreClient.CONFIG.activeProfile = "";
                PzyMoveHorreClient.CONFIG.save();
            }
            return deleted;
        } catch (IOException exception) {
            PzyMoveHorreClient.LOGGER.error("Could not delete PZY profile {}", safe, exception);
            return false;
        }
    }

    public static List<String> list() {
        try {
            Files.createDirectories(PROFILE_DIR);
            try (Stream<Path> files = Files.list(PROFILE_DIR)) {
                return files.filter(Files::isRegularFile)
                    .map(path -> path.getFileName().toString())
                    .filter(file -> file.endsWith(".json"))
                    .map(file -> file.substring(0, file.length() - 5))
                    .sorted(String.CASE_INSENSITIVE_ORDER)
                    .toList();
            }
        } catch (IOException exception) {
            PzyMoveHorreClient.LOGGER.warn("Could not list PZY profiles", exception);
            return List.of();
        }
    }

    private static String normalize(String name) {
        if (name == null) return null;
        String trimmed = name.trim();
        if (!SAFE_NAME.matcher(trimmed).matches() || trimmed.equals(".") || trimmed.equals("..")) return null;
        return trimmed;
    }

    private static String fileName(String name) {
        return name.toLowerCase(Locale.ROOT).replace(' ', '_') + ".json";
    }
}
