# PZY MOVE HORRE 1.0.1 — Fabric / Minecraft 1.21.1

โปรเจกต์ม็อด Client-side ที่เขียนใหม่แยกจาก PZY รุ่นเก่า สำหรับ Minecraft 1.21.1, Fabric Loader และ Java 21

> 1.0.1: แก้ import และ Mixin descriptor ของ ModelTransformationMode ให้ตรงกับ Yarn Minecraft 1.21.1

## ระบบที่ทำงานในฐานนี้

- จุดแทรก Render มือมุมมองบุคคลที่ 1 โดยใช้โมเดลแขนและสกินของผู้เล่นจาก Minecraft
- แยก transform ของแขนกับไอเท็มที่ถือคนละ render layer และแยก Main Hand / Offhand
- รองรับการแสดงมือว่างอีกข้าง และคำนวณด้านซ้าย/ขวาตามมือหลักของผู้เล่น
- เก็บข้อมูลเดิน วิ่ง หมอบ ตก คลาน ปีน ว่ายน้ำ ร่อน Elytra นั่งเรือ ความเร็ว การเร่ง และการหันกล้อง
- ฟิสิกส์สปริงแยกแขนและไอเท็มในแต่ละมือ พร้อมค่าความแรงและ damping
- ท่าทางพื้นฐานแบบ procedural สำหรับ idle, เดิน, วิ่ง, หมอบ, ตก, คลาน, ปีน, ว่ายน้ำ, Elytra, เรือ, หนาว และไฟ
- จำแนกประเภทไอเท็ม และ Item Blacklist ที่รองรับไอเท็มเดี่ยว, mod namespace และ wildcard `*` / `?` พร้อม scope BOTH / MAIN / OFF
- ระบบ config แบบบันทึกถาวร, ป้องกันค่าผิดรูปแบบ, โปรไฟล์ และ Hand Editor แยกสองมือ พร้อมแสดงค่าตำแหน่ง/องศา/สเกลขณะปรับ
- ระบบ Animation Pack แบบโฟลเดอร์หรือ ZIP, เลือกแพ็กแยกตามหมวดไอเท็ม, เปิด/ปิดแพ็ก, เลือกกฎตามไอเท็ม/มือ/action และโหลดใหม่ด้วยปุ่ม K โดยจำกัดขนาดรวมต่อแพ็กและจำนวน keyframe เพื่อป้องกันไฟล์แพ็กขนาดใหญ่ผิดปกติ
- Runtime เล่น keyframe แบบ loop/one-shot, fade-in/fade-out, interpolation มุมหมุน และ channel แยกมือ
- ตรวจจับม็อดที่อาจทับซ้อน และหยุด PZY render เมื่อเปิด First Person Model Auto-hide

## ปุ่มควบคุม

- `F8` — เปิดเมนู PZY
- `I` — ส่ง action `inspect` ให้ Animation Pack ของไอเท็มที่ถือ
- `K` — โหลด Animation Pack ใหม่จากโฟลเดอร์ config

ในเมนูมีหน้า General, Movement, Physics, Item Blacklist, Compatibility, Animation Packs, Profiles, Hand Editor และ Help

## Build JAR ด้วย GitHub Actions

ส่งมอบโปรเจกต์ด้วยไฟล์ Source ZIP หนึ่งไฟล์ และไฟล์ `build.yml` แยกหนึ่งไฟล์

1. อัปโหลด `PZY_MOVE_HORRE_1.0.1_Source.zip` ไว้ที่ราก Repository โดยไม่ต้องแตก ZIP
2. วาง `build.yml` ที่ `.github/workflows/build.yml`
3. Commit และ Push
4. เปิดแท็บ **Actions** เลือก **Build PZY MOVE HORRE** แล้วกด **Run workflow** (หรือให้ workflow ทำงานจากการ Push)
5. ดาวน์โหลด Artifact `PZY-MOVE-HORRE-1.0.1-Fabric-1.21.1`

JAR สำหรับติดตั้งชื่อ `pzy_move_horre-1.0.1.jar` ให้นำไปไว้ใน `mods` พร้อม Fabric Loader, Fabric API และ Java 21 ตามเวอร์ชันที่กำหนด

## ตำแหน่ง config ในเกม

- ตั้งค่า: `.minecraft/config/pzy_move_horre/pzy_config.json`
- Animation Packs: `.minecraft/config/pzy_move_horre/packs/`
- Profiles: `.minecraft/config/pzy_move_horre/profiles/`

สามารถวางแพ็กเป็นโฟลเดอร์ที่มี `pzy_pack.json` อยู่ที่ราก หรือวาง ZIP ที่มี `pzy_pack.json` อยู่ที่รากของ ZIP แล้วกด `K`

## รูปแบบ Animation Pack (schema 1)

ตัวอย่าง `pzy_pack.json`:

```json
{
  "schema": 1,
  "id": "creator:example",
  "name": "Example Pack",
  "author": "Creator",
  "version": "1.0.1",
  "description": "Example PZY animation pack",
  "priority": 10,
  "enabled": true,
  "clips": {
    "inspect_sword": "clips/inspect_sword.json"
  },
  "rules": [
    {
      "selector": "minecraft:*_sword",
      "category": "SWORD",
      "hand": "BOTH",
      "actions": {
        "inspect": "inspect_sword",
        "attack": "inspect_sword"
      }
    }
  ]
}
```

`selector` ใช้ item ID เต็ม, mod namespace เช่น `examplemod` หรือ wildcard เช่น `*_sword` และ `minecraft:*_sword` ได้ `category` เว้นว่างได้ ส่วน `hand` ใช้ `BOTH`, `MAIN` หรือ `OFF`

Action ที่ระบบส่งให้ pack ได้แก่ `attack`, `mine`, `place`, `interact_block`, `interact_item`, `equip`, `unequip`, `inspect`, `release`, `use`, `eat`, `drink`, `block`, `bow_draw`, `crossbow_load`, `spear_charge`, `spyglass`, `horn` และ `brush`

ตัวอย่างไฟล์คลิป `clips/inspect_sword.json`:

```json
{
  "id": "inspect_sword",
  "lengthTicks": 10,
  "fadeInTicks": 2,
  "fadeOutTicks": 3,
  "loop": false,
  "bones": {
    "arm": [
      { "tick": 0, "rotateX": 0, "rotateY": 0, "rotateZ": 0 },
      { "tick": 10, "rotateX": -12, "rotateY": 4, "rotateZ": 8 }
    ],
    "main_arm": [
      { "tick": 0, "rotateX": 0 },
      { "tick": 10, "rotateX": -16 }
    ],
    "item": [
      { "tick": 0, "rotateX": 0 },
      { "tick": 10, "rotateX": 8 }
    ]
  }
}
```

ช่องกระดูกที่รองรับคือ `root`, `arm`, `item` และช่องเฉพาะมือ `main_root`, `off_root`, `main_arm`, `off_arm`, `main_item`, `off_item` หากไม่มีช่องเฉพาะมือ ระบบจะย้อนกลับไปใช้ช่องร่วม

ค่า keyframe ใช้ตำแหน่งเป็นหน่วยบล็อก, มุมเป็นองศา และ `scale` เป็นตัวคูณขนาด ค่าที่เกินขอบเขตจะถูก clamp ก่อนนำไปใช้เพื่อป้องกัน render ผิดพลาด

## ขอบเขตที่ยังไม่รวมในฐานระบบนี้

นี่คือโปรเจกต์ใหม่พร้อมระบบพื้นฐานและ Build workflow ไม่ใช่การคัดลอก Punchy และยังไม่ใช่การประกาศว่าระบบเทียบเท่า Punchy ครบทุกส่วนแล้ว

- ยังไม่มีชุดคลิปแอนิเมชัน PZY สำเร็จรูปสำหรับทุกประเภทไอเท็ม — runtime และ pack loader เตรียมไว้สำหรับระยะพัฒนาแอนิเมชัน
- หน้า Compatibility ในรุ่นนี้ตรวจจับการติดตั้งม็อดเป็นหลัก มีการ defer ให้ First Person Model เท่านั้น ยังไม่มี adapter เฉพาะของม็อดอื่นทั้งหมด
- ระบบ particle, model parts, world object effects และเอฟเฟกต์เฉพาะม็อดยังไม่รวมในรุ่นนี้ จึงไม่มีสวิตช์หลอกในหน้า Settings
- ต้องรัน GitHub Actions เพื่อยืนยันการคอมไพล์ด้วย Gradle/Loom และทดสอบใน Minecraft 1.21.1 ก่อนเรียกเป็นรุ่นพร้อมใช้งาน
