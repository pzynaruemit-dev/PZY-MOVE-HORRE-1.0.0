package pzy.move.horre.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import pzy.move.horre.PzyMoveHorreClient;
import pzy.move.horre.compat.PzyCompatManager;
import pzy.move.horre.config.PzyConfig;
import pzy.move.horre.config.PzyHandPose;
import pzy.move.horre.items.PzyBlacklistEntry;
import pzy.move.horre.items.PzyItemCategory;
import pzy.move.horre.packs.PzyLoadedPack;
import pzy.move.horre.packs.PzyPackManager;
import pzy.move.horre.profiles.PzyProfileManager;
import pzy.move.horre.render.PzyHandEditor;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** In-game settings, profiles, blacklist, pack mixer and per-hand placement editor. */
public final class PzyConfigScreen extends Screen {
    private final Screen parent;
    private Tab selectedTab = Tab.GENERAL;
    private TextFieldWidget textField;
    private Hand editedHand = Hand.MAIN_HAND;
    private PzyItemCategory selectedCategory = PzyItemCategory.SWORD;
    private String notice = "";
    private final List<UiText> textLines = new ArrayList<>();

    public PzyConfigScreen(Screen parent) {
        super(Text.translatable("screen.pzy.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        rebuild();
    }

    private void rebuild() {
        clearChildren();
        textLines.clear();
        textField = null;
        int left = (width - 590) / 2;
        int top = (height - 350) / 2;

        int tabY = top + 42;
        for (Tab tab : Tab.values()) {
            int y = tabY + tab.ordinal() * 23;
            addDrawableChild(ButtonWidget.builder(Text.literal(tab.label), button -> {
                selectedTab = tab;
                notice = "";
                rebuild();
            }).dimensions(left + 8, y, 118, 20).build());
        }

        int contentX = left + 142;
        int contentY = top + 48;
        switch (selectedTab) {
            case GENERAL -> buildGeneral(contentX, contentY);
            case MOVEMENT -> buildMovement(contentX, contentY);
            case PHYSICS -> buildPhysics(contentX, contentY);
            case BLACKLIST -> buildBlacklist(contentX, contentY);
            case COMPAT -> buildCompatibility(contentX, contentY);
            case PACKS -> buildPacks(contentX, contentY);
            case PROFILES -> buildProfiles(contentX, contentY);
            case HAND_EDITOR -> buildHandEditor(contentX, contentY);
            case HELP -> buildHelp(contentX, contentY);
        }

        addDrawableChild(ButtonWidget.builder(Text.literal(PzyMoveHorreClient.CONFIG.enabled ? "PZY: ON" : "PZY: OFF"), button -> {
            PzyMoveHorreClient.CONFIG.enabled = !PzyMoveHorreClient.CONFIG.enabled;
            saveAndRebuild();
        }).dimensions(left + 8, top + 13, 118, 22).build());
        addDrawableChild(ButtonWidget.builder(Text.translatable("screen.pzy.done"), button -> close())
            .dimensions(left + 470, top + 316, 108, 22).build());
        if (!notice.isBlank()) addDrawableChild(ButtonWidget.builder(Text.literal(notice), button -> { notice = ""; rebuild(); })
            .dimensions(contentX, top + 316, 300, 22).build());
    }

    private void buildGeneral(int x, int y) {
        int row = y;
        row = toggle(x, row, "Show both hands", PzyMoveHorreClient.CONFIG.showBothHands, () -> PzyMoveHorreClient.CONFIG.showBothHands = !PzyMoveHorreClient.CONFIG.showBothHands);
        row = toggle(x, row, "Vanilla empty hand", PzyMoveHorreClient.CONFIG.vanillaEmptyHand, () -> PzyMoveHorreClient.CONFIG.vanillaEmptyHand = !PzyMoveHorreClient.CONFIG.vanillaEmptyHand);
        row = toggle(x, row, "Reduce motion", PzyMoveHorreClient.CONFIG.reduceMotion, () -> PzyMoveHorreClient.CONFIG.reduceMotion = !PzyMoveHorreClient.CONFIG.reduceMotion);
        row = toggle(x, row, "Idle hand sway", PzyMoveHorreClient.CONFIG.enableIdleSway, () -> PzyMoveHorreClient.CONFIG.enableIdleSway = !PzyMoveHorreClient.CONFIG.enableIdleSway);
        row = toggle(x, row, "Crouching pose", PzyMoveHorreClient.CONFIG.enableCrouchAnimation, () -> PzyMoveHorreClient.CONFIG.enableCrouchAnimation = !PzyMoveHorreClient.CONFIG.enableCrouchAnimation);
        addRowButton(x, row, "Animation speed: " + fmt(PzyMoveHorreClient.CONFIG.animationSpeed), () -> {
            PzyMoveHorreClient.CONFIG.animationSpeed = wrap(PzyMoveHorreClient.CONFIG.animationSpeed + 0.25f, 0.25f, 3.0f);
        });
        row += 27;
        addRowButton(x, row, "Reset settings to defaults", () -> { PzyMoveHorreClient.CONFIG.resetSettings(); notice = "Settings reset"; });
    }

    private void buildMovement(int x, int y) {
        int row = y;
        row = toggle(x, row, "Custom walk sway", PzyMoveHorreClient.CONFIG.enableCustomWalk, () -> PzyMoveHorreClient.CONFIG.enableCustomWalk = !PzyMoveHorreClient.CONFIG.enableCustomWalk);
        row = toggle(x, row, "Sprint arm swing", PzyMoveHorreClient.CONFIG.enableSprintArmSwing, () -> PzyMoveHorreClient.CONFIG.enableSprintArmSwing = !PzyMoveHorreClient.CONFIG.enableSprintArmSwing);
        row = toggle(x, row, "Falling pose", PzyMoveHorreClient.CONFIG.enableFallArmAnimation, () -> PzyMoveHorreClient.CONFIG.enableFallArmAnimation = !PzyMoveHorreClient.CONFIG.enableFallArmAnimation);
        row = toggle(x, row, "Crawling pose", PzyMoveHorreClient.CONFIG.enableCrawlAnimation, () -> PzyMoveHorreClient.CONFIG.enableCrawlAnimation = !PzyMoveHorreClient.CONFIG.enableCrawlAnimation);
        row = toggle(x, row, "Climbing pose", PzyMoveHorreClient.CONFIG.enableClimbAnimation, () -> PzyMoveHorreClient.CONFIG.enableClimbAnimation = !PzyMoveHorreClient.CONFIG.enableClimbAnimation);
        row = toggle(x, row, "Swimming pose", PzyMoveHorreClient.CONFIG.enableSwimAnimation, () -> PzyMoveHorreClient.CONFIG.enableSwimAnimation = !PzyMoveHorreClient.CONFIG.enableSwimAnimation);
        row = toggle(x, row, "Elytra pose", PzyMoveHorreClient.CONFIG.enableElytraFlightAnimation, () -> PzyMoveHorreClient.CONFIG.enableElytraFlightAnimation = !PzyMoveHorreClient.CONFIG.enableElytraFlightAnimation);
        row = toggle(x, row, "Boat/raft pose", PzyMoveHorreClient.CONFIG.enableBoatFirstPersonAnimations, () -> PzyMoveHorreClient.CONFIG.enableBoatFirstPersonAnimations = !PzyMoveHorreClient.CONFIG.enableBoatFirstPersonAnimations);
        row = toggle(x, row, "Freezing shake", PzyMoveHorreClient.CONFIG.enableFreezeShake, () -> PzyMoveHorreClient.CONFIG.enableFreezeShake = !PzyMoveHorreClient.CONFIG.enableFreezeShake);
        toggle(x, row, "Fire sway", PzyMoveHorreClient.CONFIG.enableEnhancedFireEffects, () -> PzyMoveHorreClient.CONFIG.enableEnhancedFireEffects = !PzyMoveHorreClient.CONFIG.enableEnhancedFireEffects);
    }

    private void buildPhysics(int x, int y) {
        int row = y;
        row = toggle(x, row, "Arm physics", PzyMoveHorreClient.CONFIG.enableArmPhysics, () -> PzyMoveHorreClient.CONFIG.enableArmPhysics = !PzyMoveHorreClient.CONFIG.enableArmPhysics);
        row = toggle(x, row, "Held-item physics", PzyMoveHorreClient.CONFIG.enableItemPhysics, () -> PzyMoveHorreClient.CONFIG.enableItemPhysics = !PzyMoveHorreClient.CONFIG.enableItemPhysics);
        row = valueRow(x, row, "Arm physics strength", PzyMoveHorreClient.CONFIG.armPhysicsStrength, 3.0f, v -> PzyMoveHorreClient.CONFIG.armPhysicsStrength = v);
        row = valueRow(x, row, "Item physics strength", PzyMoveHorreClient.CONFIG.itemPhysicsStrength, 3.0f, v -> PzyMoveHorreClient.CONFIG.itemPhysicsStrength = v);
        valueRow(x, row, "Physics damping", PzyMoveHorreClient.CONFIG.physicsDamping, 0.99f, v -> PzyMoveHorreClient.CONFIG.physicsDamping = v);
    }

    private void buildBlacklist(int x, int y) {
        textField = new TextFieldWidget(textRenderer, x, y, 270, 20, Text.literal("Item id / mod id / glob"));
        textField.setMaxLength(128);
        textField.setPlaceholder(Text.literal("minecraft:*_sword"));
        addDrawableChild(textField);
        addDrawableChild(ButtonWidget.builder(Text.literal("Add"), button -> {
            String value = textField.getText().trim();
            if (!value.isEmpty() && PzyMoveHorreClient.CONFIG.blacklist.stream().noneMatch(entry -> value.equalsIgnoreCase(entry.pattern))) {
                PzyMoveHorreClient.CONFIG.blacklist.add(new PzyBlacklistEntry(value));
                PzyMoveHorreClient.CONFIG.save();
                notice = "Added: " + value;
            }
            rebuild();
        }).dimensions(x + 276, y, 56, 20).build());
        int row = y + 30;
        List<PzyBlacklistEntry> entries = new ArrayList<>(PzyMoveHorreClient.CONFIG.blacklist);
        for (int i = 0; i < Math.min(entries.size(), 8); i++) {
            PzyBlacklistEntry entry = entries.get(i);
            int index = PzyMoveHorreClient.CONFIG.blacklist.indexOf(entry);
            addDrawableChild(ButtonWidget.builder(Text.literal(entry.pattern + "  [" + entry.hand + "]"), button -> {
                entry.hand = switch (entry.hand) { case "BOTH" -> "MAIN"; case "MAIN" -> "OFF"; default -> "BOTH"; };
                saveAndRebuild();
            }).dimensions(x, row, 246, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Remove"), button -> {
                if (index >= 0 && index < PzyMoveHorreClient.CONFIG.blacklist.size()) PzyMoveHorreClient.CONFIG.blacklist.remove(index);
                saveAndRebuild();
            }).dimensions(x + 252, row, 78, 20).build());
            row += 23;
        }
        addText(x, row + 2, "Click entry to cycle BOTH / MAIN / OFF. Wildcards: * and ?.");
    }

    private void buildCompatibility(int x, int y) {
        int row = y;
        row = toggle(x, row, "Auto-hide with First Person Model", PzyMoveHorreClient.CONFIG.firstPersonModelAutoHide,
            () -> PzyMoveHorreClient.CONFIG.firstPersonModelAutoHide = !PzyMoveHorreClient.CONFIG.firstPersonModelAutoHide);
        addText(x, row + 3, "Detected mods (presence check only):");
        int detectedY = row + 20;
        for (Map.Entry<String, Boolean> entry : PzyCompatManager.getDetectedMods().entrySet()) {
            if (detectedY > height - 34) break;
            addText(x, detectedY, entry.getKey() + ": " + (entry.getValue() ? "Installed" : "Not installed"));
            detectedY += 13;
        }
        addText(x, Math.min(detectedY + 4, height - 30), "Other integrations require dedicated adapters.");
    }

    private void buildPacks(int x, int y) {
        int row = y;
        addRowButton(x, row, "Item category: " + selectedCategory.name(), () -> {
            PzyItemCategory[] values = PzyItemCategory.values();
            selectedCategory = values[(selectedCategory.ordinal() + 1) % values.length];
        });
        row += 27;

        String selectedPack = PzyMoveHorreClient.CONFIG.packChoices.getOrDefault(selectedCategory.name(), "pzy:default");
        addRowButton(x, row, "Selected pack: " + selectedPack + "  [cycle enabled]", () -> {
            List<PzyLoadedPack> enabled = PzyPackManager.getPacks().stream()
                .filter(pack -> PzyPackManager.isEnabled(pack.manifest.id)).toList();
            if (enabled.isEmpty()) return;
            int current = 0;
            for (int i = 0; i < enabled.size(); i++) {
                if (enabled.get(i).manifest.id.equals(selectedPack)) current = i;
            }
            String next = enabled.get((current + 1) % enabled.size()).manifest.id;
            PzyMoveHorreClient.CONFIG.packChoices.put(selectedCategory.name(), next);
        });
        row += 30;
        float categorySpeed = PzyMoveHorreClient.CONFIG.categoryAnimationSpeeds.getOrDefault(selectedCategory.name(), 1.0f);
        addRowButton(x, row, "Category animation speed: " + fmt(categorySpeed), () -> {
            float next = categorySpeed + 0.25f;
            PzyMoveHorreClient.CONFIG.categoryAnimationSpeeds.put(selectedCategory.name(), next > 4.0f ? 0.25f : next);
        });
        row += 27;

        addText(x, row, "Installed animation packs (toggle to enable):");
        row += 17;
        int shownPacks = 0;
        for (PzyLoadedPack pack : PzyPackManager.getPacks()) {
            if (shownPacks++ >= 7) break;
            boolean builtIn = "pzy:default".equals(pack.manifest.id);
            boolean enabled = PzyPackManager.isEnabled(pack.manifest.id);
            String titleText = pack.manifest.name + "  [" + pack.manifest.id + "]";
            addText(x, row + 5, titleText.length() > 37 ? titleText.substring(0, 34) + "..." : titleText);
            if (!builtIn) {
                addDrawableChild(ButtonWidget.builder(Text.literal(enabled ? "Enabled" : "Disabled"), button -> {
                    PzyPackManager.setEnabled(pack.manifest.id, !PzyPackManager.isEnabled(pack.manifest.id));
                    notice = pack.manifest.name + (PzyPackManager.isEnabled(pack.manifest.id) ? " enabled" : " disabled");
                    rebuild();
                }).dimensions(x + 250, row, 86, 20).build());
            } else {
                addText(x + 250, row + 5, "Built-in");
            }
            row += 23;
        }
        addText(x, Math.min(row + 3, height - 34), "Folder: config/pzy_move_horre/packs  |  Reload: K");
    }

    private void buildProfiles(int x, int y) {
        textField = new TextFieldWidget(textRenderer, x, y, 250, 20, Text.literal("Profile name"));
        textField.setMaxLength(32);
        textField.setPlaceholder(Text.literal("My setup"));
        addDrawableChild(textField);
        addDrawableChild(ButtonWidget.builder(Text.literal("Save current"), button -> {
            notice = PzyProfileManager.save(textField.getText()) ? "Profile saved" : "Invalid profile name";
            rebuild();
        }).dimensions(x + 256, y, 100, 20).build());
        int row = y + 30;
        int shownProfiles = 0;
        for (String profile : PzyProfileManager.list()) {
            if (shownProfiles++ >= 8) break;
            addDrawableChild(ButtonWidget.builder(Text.literal("Load  " + profile), button -> {
                notice = PzyProfileManager.load(profile) ? "Profile loaded" : "Could not load profile";
                rebuild();
            }).dimensions(x, row, 175, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Delete"), button -> {
                PzyProfileManager.delete(profile); rebuild();
            }).dimensions(x + 182, row, 72, 20).build());
            row += 23;
        }
        addText(x, row + 5, "Profiles include settings, item rules, pack choices and hand poses.");
    }

    private void buildHandEditor(int x, int y) {
        addRowButton(x, y, "Editing: " + (editedHand == Hand.MAIN_HAND ? "Main hand" : "Off hand"), () -> {
            editedHand = editedHand == Hand.MAIN_HAND ? Hand.OFF_HAND : Hand.MAIN_HAND;
        });
        int row = y + 31;
        PzyHandPose currentPose = PzyHandEditor.getPose(editedHand);
        for (PzyHandEditor.Axis axis : PzyHandEditor.Axis.values()) {
            addText(x, row + 3, axis.name() + ": " + fmt(poseValue(currentPose, axis)));
            addDrawableChild(ButtonWidget.builder(Text.literal("−"), button -> {
                PzyHandEditor.adjust(editedHand, axis, -step(axis));
                rebuild();
            }).dimensions(x + 120, row, 28, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("+"), button -> {
                PzyHandEditor.adjust(editedHand, axis, step(axis));
                rebuild();
            }).dimensions(x + 152, row, 28, 20).build());
            row += 25;
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Reset hand"), button -> {
            PzyHandEditor.reset(editedHand);
            saveAndRebuild();
        }).dimensions(x + 190, y + 31, 145, 20).build());
        addText(x, row + 2, "Position and rotation values save immediately to PZY config.");
    }

    private void buildHelp(int x, int y) {
        addRowButton(x, y, "Copy debug information", () -> {
            if (client != null) client.keyboard.setClipboard(debugInfo());
            notice = "Debug info copied";
        });
        addText(x, y + 34, "PZY MOVE HORRE 1.0.1 — Minecraft 1.21.1 / Fabric");
        addText(x, y + 51, "Open menu: F8    Inspect: I    Reload packs: K");
        addText(x, y + 68, "Config: config/pzy_move_horre/pzy_config.json");
        addText(x, y + 85, "Packs: config/pzy_move_horre/packs");
        addText(x, y + 102, "Profiles: config/pzy_move_horre/profiles");
        addText(x, y + 119, "Clip format: PZY pzy_pack.json + clips/*.json");
    }

    private int toggle(int x, int y, String label, boolean value, Runnable change) {
        addRowButton(x, y, label + ": " + (value ? "ON" : "OFF"), change);
        return y + 25;
    }

    private int valueRow(int x, int y, String label, float value, float max, java.util.function.Consumer<Float> setter) {
        addRowButton(x, y, label + ": " + fmt(value), () -> setter.accept(wrap(value + 0.1f, 0.0f, max)));
        return y + 25;
    }

    private void addRowButton(int x, int y, String label, Runnable action) {
        addDrawableChild(ButtonWidget.builder(Text.literal(label), button -> {
            action.run();
            saveAndRebuild();
        }).dimensions(x, y, 340, 20).build());
    }

    private void addText(int x, int y, String text) {
        textLines.add(new UiText(x, y, text));
    }

    private void saveAndRebuild() {
        PzyMoveHorreClient.CONFIG.save();
        rebuild();
    }

    private static float poseValue(PzyHandPose pose, PzyHandEditor.Axis axis) {
        return switch (axis) {
            case X -> pose.x;
            case Y -> pose.y;
            case Z -> pose.z;
            case ROTATE_X -> pose.rotateX;
            case ROTATE_Y -> pose.rotateY;
            case ROTATE_Z -> pose.rotateZ;
            case SCALE -> pose.scale;
        };
    }

    private static float step(PzyHandEditor.Axis axis) { return switch (axis) { case SCALE -> 0.05f; case ROTATE_X, ROTATE_Y, ROTATE_Z -> 2.0f; default -> 0.01f; }; }
    private static float wrap(float value, float min, float max) { return value > max ? min : value; }
    private static String fmt(float value) { return String.format(java.util.Locale.ROOT, "%.2f", value); }

    private String debugInfo() {
        return "PZY MOVE HORRE 1.0.1\nMinecraft: 1.21.1\nLoader: Fabric\n" +
            "Active profile: " + PzyMoveHorreClient.CONFIG.activeProfile + "\n" +
            "Blacklist entries: " + PzyMoveHorreClient.CONFIG.blacklist.size() + "\n" +
            "Loaded packs: " + PzyPackManager.getPacks().size() + "\n" + PzyCompatManager.debugSummary();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        int left = (width - 590) / 2;
        int top = (height - 350) / 2;
        context.fill(left, top, left + 590, top + 350, 0xE51A1A1A);
        context.drawCenteredTextWithShadow(textRenderer, title, left + 295, top + 6, 0xFFFFFF);
        context.drawTextWithShadow(textRenderer, Text.literal(selectedTab.label), left + 142, top + 30, 0xFFD36B);
        for (UiText line : textLines) context.drawTextWithShadow(textRenderer, Text.literal(line.text), line.x, line.y, 0xD7D7D7);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        PzyMoveHorreClient.CONFIG.save();
        if (client != null) client.setScreen(parent);
    }

    private record UiText(int x, int y, String text) { }

    private enum Tab {
        GENERAL("General"), MOVEMENT("Movement"), PHYSICS("Physics"), BLACKLIST("Item Blacklist"),
        COMPAT("Compatibility"), PACKS("Animation Packs"), PROFILES("Profiles"), HAND_EDITOR("Hand Editor"), HELP("Help");
        final String label;
        Tab(String label) { this.label = label; }
    }
}
